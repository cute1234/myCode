package com.newegg.bi.utils.logx;

public enum SeverityLevel {
    DEBUG("DEBUG"),
    ERROR("ERROR"),
    FATAL("FATAL"),
    INFO("INFO"),
    UNKNOW("UNKNOW"),
    WARN("WARN");

    private String value;

    SeverityLevel(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
