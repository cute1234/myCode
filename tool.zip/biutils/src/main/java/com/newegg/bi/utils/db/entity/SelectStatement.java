package com.newegg.bi.utils.db.entity;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;
import com.newegg.bi.utils.common.StringUtils;

/**
 * 組sql select 語句
 * @author bl5s
 *
 */
public class SelectStatement {
	List<SelectEntity> list;
	public SelectStatement() {
		list=new ArrayList<SelectEntity>();
	}
	public void addSelect(String field,String alias) {
		list.add(new SelectEntity(field, alias));
	}
	
	/**
	 * 給子查詢使用
	 * 這邊alias 應該要必填，但是這包共用的有點多....jar不敢隨意加，怕有衝突 XD 
	 * 反正沒寫alias ， 下sql 一定會錯	
	 * @param sqlBuilder
	 * @param alias
	 */
	public void addSelect(SqlBuilder sqlBuilder, String alias) {
		StringBuffer subSelect=new StringBuffer();
		subSelect.append(SqlEnum.SQL_PARENTHESES_S.getValue());
		subSelect.append(sqlBuilder.buildSqlStatement());
		subSelect.append(SqlEnum.SQL_PARENTHESES_E.getValue());
		list.add(new SelectEntity(subSelect.toString(), alias));		
	}
	
	
	public String toStatement() {
		StringBuffer sb=new StringBuffer();
		
		if (null!=list && list.size()>0) {			
			for (int i = 0; i < list.size(); i++) {
				SelectEntity se=list.get(i);
				sb.append(se.getField()).append(SqlEnum.SQL_AS.getValue());
				if(StringUtils.isEmpty(se.getAlias())) {
					sb.append(se.getField());
				}else {
					sb.append(se.getAlias());
				}
				
				if (i!=list.size()-1) {
					sb.append(SqlEnum.SQL_COMMA.getValue());
				}
			}
		}
		return sb.toString();
	}
}
