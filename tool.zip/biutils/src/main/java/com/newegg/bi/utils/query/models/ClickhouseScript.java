package com.newegg.bi.utils.query.models;


public class ClickhouseScript {

    private String columnScript;
    private String whereScript;
    private String groupScript;
    private String orderScript;

    private String limitScript;

    public String getColumnScript() {
        return columnScript;
    }

    public void setColumnScript(String columnScript) {
        this.columnScript = columnScript;
    }

    public String getWhereScript() {
        return whereScript;
    }

    public void setWhereScript(String whereScript) {
        this.whereScript = whereScript;
    }

    public String getGroupScript() {
        return groupScript;
    }

    public void setGroupScript(String groupScript) {
        this.groupScript = groupScript;
    }

    public String getOrderScript() {
        return orderScript;
    }

    public void setOrderScript(String orderScript) {
        this.orderScript = orderScript;
    }

    public String getLimitScript() {
        return limitScript;
    }

    public void setLimitScript(String limitScript) {
        this.limitScript = limitScript;
    }

}
