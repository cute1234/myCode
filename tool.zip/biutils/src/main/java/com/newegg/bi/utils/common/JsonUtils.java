package com.newegg.bi.utils.common;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

public class JsonUtils {

	private static Logger logger = LoggerFactory.getLogger(JsonUtils.class);

	public static String toString(JsonElement e) {
		return toString(e, null);
	}

	public static String toString(JsonElement e, String init) {
		if (e == null || e.isJsonNull()) {
			return init;
		} else {
			return e.getAsString();
		}
	}

	public static Double toDouble(JsonElement e) {
		return toDouble(e, 0.0);
	}

	public static Double toDouble(JsonElement e, Double init) {
		if (e == null || e.isJsonNull()) {
			return init;
		} else {
			return e.getAsDouble();
		}
	}

	public static Integer toInteger(JsonElement e) {
		return toInteger(e, 0);

	}

	public static Integer toInteger(JsonElement e, Integer init) {
		if (e == null || e.isJsonNull()) {
			return init;
		} else {
			return e.getAsInt();
		}
	}

	public static Long toLong(JsonElement e) {
		if (e == null || e.isJsonNull()) {
			return null;
		} else {
			return e.getAsLong();
		}
	}

	public static JsonArray jsonArraySorting(JsonArray rtnArray, final String sortingName) {
		return jsonArraySorting(rtnArray, sortingName, true);
	}

	// old: sorting(JsonArray arr,final String sortingKeyName)
	public static JsonArray jsonArraySorting(JsonArray rtnArray, final String sortingName, final boolean asc) {
		JsonArray sortedJsonArray = new JsonArray();
		List<JsonElement> jsonList = new ArrayList<>();
		for (JsonElement e : rtnArray) {
			jsonList.add(e);
		}
		Collections.sort(jsonList, new Comparator<JsonElement>() {
			@Override
			public int compare(JsonElement a, JsonElement b) {
				String valA = new String();
				String valB = new String();
				try {
					valA = a.getAsJsonObject().get(sortingName).getAsString();
					valB = b.getAsJsonObject().get(sortingName).getAsString();
				} catch (Exception e) {
					logger.error("continentSorting error:" + e.getMessage());
				}
				if (asc) {
					return valA.compareTo(valB);
				} else {
					return valB.compareTo(valA);
				}

			}
		});
		for (JsonElement e : jsonList) {
			sortedJsonArray.add(e);
		}
		return sortedJsonArray;
	}

	// Type mapType = new TypeToken<HashMap<String,String>>(){}.getType();

	/**
	 * parser jsonArray to List<object>
	 * 
	 * @param jsonArray
	 * @param mClass
	 * @return
	 */
	protected <M> List<M> parserList(JsonArray jsonArray, Class<M> mClass) {
		List<M> list = new ArrayList<>();
		for (JsonElement e : jsonArray) {
			list.add(parser(e.getAsJsonObject(), mClass));
		}
		return list;
	}

	/**
	 * parser jsonstring JsonObject to List<object>
	 * 
	 * @param obj
	 * @return
	 */
	protected <M> List<M> parserJsonstring(JsonObject obj) {
		String jsonstring = obj.get("jsonstring").getAsString();
		// System.out.println("output json:"+jsonstring);

		Type listType = new TypeToken<ArrayList<M>>() {
		}.getType();
		List<M> list = new Gson().fromJson(jsonstring, listType);
		return list;
	}

	public <M> M parser(JsonObject jsonobj, Class<M> mClass) {
		try {
			// Method [] method = mClass.getDeclaredMethods() ;
			Method[] method = mClass.getMethods(); // include all methods
													// extending another
			M entity = mClass.newInstance();
			if (jsonobj == null || jsonobj.isJsonNull())
				return null;
			if (entity != null) {
				for (int i = 0; i < method.length; i++) {
					String methodName = method[i].getName();
					if (methodName.startsWith("set")) {
						String columnName = method[i].getName().replace("set", "");
						if (columnName.toLowerCase().equals("class"))
							continue; // ignore class name
						String type = method[i].getGenericParameterTypes()[0].toString();
						try {
							if (type.contains("Date")) {
								method[i].invoke(entity, DateUtils.getDate(jsonobj.get(columnName).getAsString(), "yyyy-MM-dd HH:mm:ss"));
							} else if (type.contains("Long") || type.contains("long")) {
								method[i].invoke(entity, isJsonEmpty(jsonobj.get(columnName)) ? 0 : jsonobj.get(columnName).getAsLong());
							} else if (type.contains("Double") || type.contains("double")) {
								method[i].invoke(entity, isJsonEmpty(jsonobj.get(columnName)) ? 0.0 : jsonobj.get(columnName).getAsDouble());
							} else if (type.contains("Integer") || type.contains("int")) {
								method[i].invoke(entity, isJsonEmpty(jsonobj.get(columnName)) ? 0 : jsonobj.get(columnName).getAsInt());
							} else {
								method[i].invoke(entity, isJsonEmpty(jsonobj.get(columnName)) ? "" : jsonobj.get(columnName).getAsString());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
			return entity;
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("parser error" + sw.toString());
			return null;
		}
	}

	public static <M> JsonArray convertJsonArray(List<M> list) throws Exception {
		JsonArray jsonArray = new JsonArray();

		for (M m : list) {
			Method[] method = m.getClass().getMethods();
			if (m != null) {
				for (int i = 0; i < method.length; i++) {
					String methodName = method[i].getName();
					String returnType = method[i].getReturnType().getName().toLowerCase();
					JsonObject o = new JsonObject();
					if (methodName.startsWith("get")) {
						String name = methodName.replace("get", "").toLowerCase();
						try {
							if (returnType.contains("double")) {
								o.addProperty(name, Double.parseDouble(method[i].invoke(m).toString()));
							} else if (returnType.contains("integer") || returnType.contains("int")) {
								o.addProperty(name, Integer.parseInt(method[i].invoke(m).toString()));
							} else {
								o.addProperty(name, method[i].invoke(m).toString());
							}
							jsonArray.add(o);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		return jsonArray;
	}

	public static boolean isJsonEmpty(JsonElement e) {
		if (e == null || e.isJsonNull())
			return true;
		if (e.isJsonArray() && e.getAsJsonArray().size() == 0)
			return true;
		return false;
	}

	public static void injectElement(JsonElement e, JsonObject result) {
		if (e != null && !e.isJsonNull()) {
			for (Entry<String, JsonElement> entry : e.getAsJsonObject().entrySet()) {
				result.add(entry.getKey(), entry.getValue());
			}
		}
	}

}
