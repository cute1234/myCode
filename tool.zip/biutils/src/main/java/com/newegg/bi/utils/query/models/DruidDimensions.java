package com.newegg.bi.utils.query.models;

public class DruidDimensions {
	//page_view expansion v4
	public static String Expand_Keywords="search_keywords";
	public static String Expand_Country="country_code";
	public static String Expand_Website="website";
	public static String Chrome_Channel="Chrome Channel";
	public static String Chrome_Pagename="Chrome Pagename";
	public static String Chrome_Prop11="Chrome Prop11";
	public static String Chrome_EVar15="Chrome eVar15";
	public static String Page_Path="Page Path";
	
	//products,pageview...
	public static String Country="Country";
	public static String Page_Output="Page Output";
	public static String Page_Type="Page Type";
	public static String Website="Website";
	public static String Keywords="Keywords"; 
	
	//product_view
	public static String Category="Category";
	public static String Subcategory="SubCateory"; //注意!!注意!!dimension name 少一個 g
	public static String Item_Number="Item Number";

	//products
	public static String Sourcing="Sourcing";

}
