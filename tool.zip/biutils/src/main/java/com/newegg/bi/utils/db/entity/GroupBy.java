package com.newegg.bi.utils.db.entity;

import java.util.ArrayList;
import java.util.List;

public class GroupBy {
	private List<String> list;
	public GroupBy() {
		list=new ArrayList<String>();
	}
	public void addGroupBy(String value) {
		list.add(value);
	}
	public void addGroupBy(String[] value) {
		if (null!= value && value.length>0) {
			for (int i = 0; i < value.length; i++) {
				list.add(value[i]);	
			}	
		}
	}
	public String toStatement() {
		StringBuffer sb=new StringBuffer();
		if ( null != list && list.size()>0) {
			sb.append(String.join(", ", list));
		}
		return sb.toString();
	}
}
