package com.newegg.bi.utils.db;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbcp2.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.newegg.bi.utils.common.EncryptUtils;
import com.newegg.bi.utils.dynamic.PropertiesUtils;

public class DatabasePool {
	private static DatabasePool container;
	private static final Logger logger = LoggerFactory.getLogger(DatabasePool.class);
	private static final String DRIVER_CLASS_NAME = PropertiesUtils.properties.getProperty("db.driver");
	private static final String DRIVER_URL = PropertiesUtils.properties.getProperty("db.url");
	private static String USERNAME = PropertiesUtils.properties.getProperty("db.username");
	private static String PASSWORD = EncryptUtils.getInstance().decrypt(PropertiesUtils.properties.getProperty("db.password"));
	private static final int CONN_POOL_SIZE = 5;

	private BasicDataSource dataSource = new BasicDataSource();

	private DatabasePool() {
		try {
			this.dataSource.setDriverClassName(DRIVER_CLASS_NAME);
			this.dataSource.setUrl(DRIVER_URL);
			this.dataSource.setUsername(USERNAME);
			this.dataSource.setPassword(PASSWORD);
			this.dataSource.setInitialSize(CONN_POOL_SIZE);
		} catch (Exception e) {
			logger.error("[db container error]", e);
		}
	}
	
	public static DatabasePool getInstances() {
		if (container == null) {
			synchronized (DatabasePool.class) {
				if (container == null)
					container = new DatabasePool();
			}
		}
		return container;
	}

	public Connection getConnection() throws SQLException {
		return this.dataSource.getConnection();
	}
	
	public JsonArray commonQuery(String script) throws Exception {
		JsonArray result = null;
		logger.info(script);

		Connection connMySQL;
		try {
			connMySQL = getConnection();
			PreparedStatement stmt = connMySQL.prepareStatement(script);
			// stmt.setString(1, reportName);
			ResultSet res = stmt.executeQuery();

			result = Parser.convert(res);
			res.close();
			res = null;
			connMySQL.close();
		} catch (SQLException e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String exceptionAsString = sw.toString();
			logger.error(exceptionAsString);
			throw new Exception(exceptionAsString);
		} finally {
			connMySQL = null;
		}
		return result;
	}
	public String commonUpdate(String script,String[] parameters) throws Exception {
		String result = null;
		logger.info(script);

		Connection connMySQL;
		try {
			connMySQL = getConnection();
			PreparedStatement stmt = connMySQL.prepareStatement(script);
			for (int i = 0; i < parameters.length; i++) {
				stmt.setString(i+1, parameters[i]);
			}
			stmt.executeUpdate();

			result = "update success";
	
			connMySQL.close();
		} catch (SQLException e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String exceptionAsString = sw.toString();
			logger.error(exceptionAsString);
			result = "update error";
			throw new Exception(exceptionAsString);
		} finally {
			connMySQL = null;
		}
		return result;
	}
	

}
