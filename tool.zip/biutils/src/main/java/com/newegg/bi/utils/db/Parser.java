package com.newegg.bi.utils.db;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class Parser {
	public static JsonArray convert(ResultSet resultSet) throws Exception {
		JsonArray jsonArray = new JsonArray();
		ResultSetMetaData meta = resultSet.getMetaData();
		int columns = meta.getColumnCount();
		System.out.println("columns:" + columns);

		while (resultSet.next()) {
			JsonObject obj = new JsonObject();

			for (int i = 1; i <= columns; i++) {
				String columnType = meta.getColumnTypeName(i).toLowerCase();
				String columnName = meta.getColumnName(i).toLowerCase();
				switch (columnType) {
				case "money":
				case "decimal":
				case "float":
				case "int":
				case "numeric":
					
					obj.addProperty(columnName, resultSet.getDouble(i));
					break;
				default:
					obj.addProperty(columnName, resultSet.getString(i));
				}
			}
			if (!obj.isJsonNull())
				jsonArray.add(obj);
		}
		return jsonArray;
	}
}
