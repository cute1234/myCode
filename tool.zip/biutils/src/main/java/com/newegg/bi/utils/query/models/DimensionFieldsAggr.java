package com.newegg.bi.utils.query.models;

public class DimensionFieldsAggr {
	private String type;
	private String dimension;
	private String outputName;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDimension() {
		return dimension;
	}

	public void setDimension(String dimension) {
		this.dimension = dimension;
	}

	public DimensionFieldsAggr() {
	}

	public DimensionFieldsAggr(String type, String dimension, String outputName) {
		this.type = type;
		this.dimension = dimension;
		this.outputName = outputName;
	}

	public String getOutputName() {
		return outputName;
	}

	public void setOutputName(String outputName) {
		this.outputName = outputName;
	}
}
