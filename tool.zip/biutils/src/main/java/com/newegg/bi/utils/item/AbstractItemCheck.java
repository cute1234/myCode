package com.newegg.bi.utils.item;

/**
 * 貨號的檢查 用責任鍊的方式丟下去檢查
 * @author bl5s
 *
 */
public abstract class AbstractItemCheck {
	public static ItemCheckEnum itemEnum;
	protected AbstractItemCheck nextItemCheck;
	public void setNextLogger(AbstractItemCheck nextItemCheck) {
		this.nextItemCheck = nextItemCheck;
	}
	public int itemCheck(ItemCheckEnum itemCheckEnum,String itemNumber){
		if (itemEnum.equals(itemCheckEnum)) {
			boolean status=proc(itemNumber);
			return status? 0:1;
		}
		return (nextItemCheck !=null)? nextItemCheck.itemCheck(itemCheckEnum,itemNumber):99;
	}
	
	/**
	 * 不知道是甚麼型態，丟下去循序檢查
	 * @param itemNumber
	 * @return
	 */
	public int itemCheckUnknowType(String itemNumber){
		boolean status=proc(itemNumber);
		if (status) {
			setItemCheckEnum(itemEnum);
			return 0;
		}
		return (nextItemCheck !=null)? nextItemCheck.itemCheckUnknowType(itemNumber):99;
	}
	abstract protected   void setItemCheckEnum(ItemCheckEnum itemEnum);
	abstract protected   boolean proc(String itemNumber);
}
