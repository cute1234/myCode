package com.newegg.bi.utils.common.entity;

/**
 * 公版 Result 回復，
 * @author bl5s 
 * @param <T>
 */
public class ResultInfo<T> {
	private Integer status;
	private String message;
	private T response;
	/**
	 * 
	 * @param status   自訂回應狀態 
	 * @param message  自訂回復訊息
	 * @param response 自訂回應response
	 */
	public ResultInfo(Integer status,String message,T response) {
		setMessage(message);
		setStatus(status);
		setResponse(response);
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getResponse() {
		return response;
	}
	public void setResponse(T response) {
		this.response = response;
	}
}
