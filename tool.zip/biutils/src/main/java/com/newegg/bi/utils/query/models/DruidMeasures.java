package com.newegg.bi.utils.query.models;

public class DruidMeasures {
	//cube: page-view-expansionV4
	public static String Expand_Page_Views="pageViews";
	public static String Expand_Unique_Visitors="uniqueVisitors";
	public static String Expand_Visits="visits";
	
	//cube:products,pageview
	public static String Page_Views="Page Views";
	public static String Unique_Visitors="Unique Visitors";
	public static String Visits="Visits";


	public static String Product_Views="Product Views";
	
	public static String Quantity="Units Added to Cart";
	
	public static String Order_before="Orders before order split";
	public static String Order_after="Orders after order split";
	
	

}
