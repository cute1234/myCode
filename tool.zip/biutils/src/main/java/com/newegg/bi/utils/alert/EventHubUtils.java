package com.newegg.bi.utils.alert;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.newegg.bi.utils.common.JsonUtils;
import com.newegg.bi.utils.common.StringUtils;
import com.newegg.bi.utils.http.client.RestClient;
import com.newegg.bi.utils.mail.EmailServiceUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.entity.ContentType;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static com.newegg.bi.utils.http.client.RestClient.requestPOST;

public class EventHubUtils {

    static Logger logger = Logger.getLogger(EmailServiceUtils.class);

    private static String url = "https://apis.newegg.org/event_hub/alert";

    private static String authorization = "";

    public static boolean sendMessage(EventHubEntity alert) {
        MultivaluedMap<String, Object> header = new MultivaluedHashMap<>();
        header.add("Accept", "application/json");
        if (!StringUtils.isEmpty(authorization)) {
            header.add("Authorization", authorization);
        }

        String postData = StringUtils.toGson(alert);
        postData = postData.replace("ownerEmail", "owner-email");
        postData = postData.replace("ownerGroups", "owner-groups");
        postData = postData.replace("impactGroups", "impact-groups");
        logger.info("send alert to Event Hub:" + postData);

        try {
//            RestClient client = new RestClient(null);
//            JsonObject result = client.requestPOST(url, header, postData);
            URI uri = new URI(url);
            JsonObject result = requestPOST(uri, "service", postData);
            if (JsonUtils.isJsonEmpty(result) || JsonUtils.isJsonEmpty(result.get("code")) || !(result.get("code").toString().equals("200"))) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw)); 
            logger.error(sw.toString());
        }
        return false;
    }


    public static void main(String[] args) {
        EventHubEntity alert = new EventHubEntity();
        alert.setEnvironment("BI");
        alert.setGroup("TW BI");
        List<String> service = new ArrayList<>();
        service.add("QSPEP-Job");
        alert.setService(service);
        alert.setSeverity("Warning");
        Attributes attributes = new Attributes();
        attributes.setOwnerEmail("brock.x.lin@newegg.com");
        attributes.setOwnerGroups("brock.x.lin@newegg.com");
        attributes.setImpactGroups("brock.x.lin@newegg.com");
        attributes.setMoreInfo("<a href='https://gqc-bi.newegg.org/rmadashboard/'>rmadashboard</a>");
        alert.setValue("Warning");
        alert.setAttributes(attributes);
        alert.setOrigin("BIJobservice");
        alert.setType("testAlert");
        alert.setResource("Salesticker History/Service Revenue auto alert"); //這個
        alert.setEvent("test-Salesticker History/Service Revenue auto alert");
        logger.info(String.valueOf(EventHubUtils.sendMessage(alert)));
    }
}
