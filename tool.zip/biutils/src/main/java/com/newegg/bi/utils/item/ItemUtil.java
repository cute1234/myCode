package com.newegg.bi.utils.item;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * newegg貨號統一處理 貨號規則
 * https://confluence.newegg.org/pages/viewpage.action?pageId=5542410
 * 
 * @author bl5s
 *
 */
public class ItemUtil {
	private static List<String> notAllowPunctuationCode;
	private static List<String> notAllowPunctuation;



	/**
	 * 45 是 - 這個是可以用的 有新的要額外加，但是看confluence 不應該出現非 「-」以外的內容 2022.2.14
	 * 
	 * @param intCode
	 * @return
	 */
	static boolean isAllowPunctuationASCIICode(int intCode) {
		if (Arrays.asList(new Integer[] { 45 }).contains(intCode)) {
			return true;
		}
		return false;
	}

	/**
	 * 48- 57 >半形數字0-9
	 * 
	 * @param intCode
	 * @return
	 */
	static boolean isNumberASCIICode(int intCode) {
		if (intCode >= 48 && intCode <= 57) {
			return true;
		}
		return false;
	}

	/**
	 * 65-90>半形英文大寫A-Z
	 * 
	 * @param intCode
	 * @return
	 */
	static boolean isCapitalEnglishASCIICode(int intCode) {
		if (intCode >= 65 && intCode <= 90) {
			return true;
		}
		return false;
	}

	/**
	 * 97-122>半形英文小寫a-z
	 * 
	 * @param intCode
	 * @return
	 */
	static boolean isLowercaseEnglishASCIICode(int intCode) {
		if (intCode >= 97 && intCode <= 122) {
			return true;
		}
		return false;
	}

	static {
		notAllowPunctuationCode = new ArrayList<String>();
		notAllowPunctuation = new ArrayList<String>();
		for (int index = 0; index <= 127; index++) {
			if (!isAllowPunctuationASCIICode(index) && !isNumberASCIICode(index) && !isCapitalEnglishASCIICode(index)
					&& !isLowercaseEnglishASCIICode(index)) {
				String hexCode = Integer.toHexString(index);
				if (hexCode.length() < 2) {
					hexCode = String.format("%02d", index);// 0-9要特別處理
				}
				notAllowPunctuationCode.add("\\X" + hexCode.toUpperCase());
				notAllowPunctuationCode.add("\\x" + hexCode);
				notAllowPunctuation.add(asciiToString(index));
			}
		}
	}

	public static List<String> getNotAllowPunctuation() {
		return notAllowPunctuation;
	}

	public static void setNotAllowPunctuation(List<String> notAllowPunctuation) {
		ItemUtil.notAllowPunctuation = notAllowPunctuation;
	}

	private static String clearAllSpecialCharacters(String itemNumber) {
		// return toUnicode(itemNumber);
		String formatItem = itemNumber;
		List<String> list = notAllowPunctuationCode;
		for (int i = list.size() - 1; i > 0; i--) {
			String replaceString = list.get(i);
			if (formatItem.indexOf(replaceString) >= 0) {
				formatItem = formatItem.replace(replaceString, "");
			}
		}
		list = notAllowPunctuation;
		for (int i = list.size() - 1; i > 0; i--) {
			String replaceString = list.get(i);
			if (formatItem.indexOf(replaceString) >= 0) {
				formatItem = formatItem.replace(replaceString, "");
			}
		}
		return formatItem;
	}

	public static String asciiToString(int str) {// ASCII轉換為字串
		return new Character((char) str).toString();
	}

	public static String toUnicode(String str) {
		str = (str == null ? "" : str);
		String tmp;
		StringBuffer sb = new StringBuffer(1000);
		char c;
		int i, j;
		sb.setLength(0);
		for (i = 0; i < str.length(); i++) {
			c = str.charAt(i);
			sb.append("\\u");
			j = (c >>> 8); // 取出高8位
			tmp = Integer.toHexString(j);
			if (tmp.length() == 1)
				sb.append("0");
			sb.append(tmp);
			j = (c & 0xFF); // 取出低8位
			tmp = Integer.toHexString(j);
			if (tmp.length() == 1)
				sb.append("0");
			sb.append(tmp);

		}
		return (new String(sb));
	}

	/**
	 * 全形轉半形，在來後續的處理
	 * 
	 */
	public static String toHalfShapeString(String str) {
		for (char c : str.toCharArray()) {
			str = str.replaceAll("　", " ");
			if ((int) c >= 65281 && (int) c <= 65374) {
				str = str.replace(c, (char) (((int) c) - 65248));
			}
		}
		return str;
	}

	public static String formatterItem(String itemNumber) {
		itemNumber =clearAllSpecialCharacters(toHalfShapeString(itemNumber));
		return itemNumber;
	}
	public static boolean isRightFormat(String itemNumber) {
		if (isSellerItem(itemNumber)) {
			
		}
		return false;
	}
	private static boolean isSellerItem(String itemNumber) {
		return false;
	}
	private static boolean isNewegg(String itemNumber) {
		return false;
	}
	private static boolean isNeweggPrefix(String itemNumber) {
		return false;
	}
	private static boolean isParent() {
		return false;
	}
}
