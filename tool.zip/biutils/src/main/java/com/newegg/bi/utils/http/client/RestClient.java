package com.newegg.bi.utils.http.client;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.newegg.bi.utils.common.StringUtils;

public class RestClient {

	private static Logger logger = Logger.getLogger(RestClient.class);

	private static NumberFormat fmt = new DecimalFormat("#0.00000");
	private static ClientConfig connection_conf;
	// private static MultivaluedMap<String, Object> header_default;
	private static JsonParser jsonParser = new JsonParser();
	private static String bigdata_api_uri = "http://apis-e11s.newegg.org/BigData/v1forother/e11/QueryInIndex";
	private MultivaluedMap<String, Object> header;

	public RestClient(MultivaluedMap<String, Object> header) {
		this.header = header;
	}

	public ClientConfig get_connection_conf() {
		if (connection_conf == null) {
			connection_conf = new ClientConfig();
			connection_conf.property(ClientProperties.CONNECT_TIMEOUT, 3000);
			connection_conf.property(ClientProperties.READ_TIMEOUT, 6000);
		}
		return connection_conf;
	}
	public ClientConfig get_connection_conf(int connectSecond,int readSecond) {
		if (connection_conf == null) {
			connection_conf = new ClientConfig();		
		}
		setConnectionConf(connectSecond,readSecond);
		return connection_conf;
	}
	/**
	 * 設定 timeout 的秒數( 60  = 一分鐘timeout) 非毫秒
	 * @param connectSecond
	 * @param readSecond
	 * @return
	 */
	public ClientConfig setConnectionConf(int connectSecond,int readSecond) {
			connection_conf.property(ClientProperties.CONNECT_TIMEOUT, connectSecond*1000);
			connection_conf.property(ClientProperties.READ_TIMEOUT, readSecond*1000);
		return connection_conf;
	}

	public JsonElement requestGET(String uri, MultivaluedMap<String, Object> headerData) {
		return requestGET(uri, headerData, get_connection_conf(), false);
	}

	/**
	 *
	 * @param uri
	 * @param headerData
	 *            default json in get_header()
	 * @param conf
	 *            default in get_connection_conf()
	 * @param printErrResponse
	 *            if not Status.OK.getStatusCode()
	 * @return
	 */
	public synchronized JsonElement requestGET(String uri, MultivaluedMap<String, Object> headerData, ClientConfig conf, boolean printErrResponse) {
		Client client = null;
		try {
			client = ClientBuilder.newClient(conf);
			WebTarget webTarget = client.target(uri);
			Invocation.Builder builder = webTarget.request();
			if (headerData != null) {
				builder.headers(headerData);
			}
			Response response = builder.get();

			if (response.getStatus() == Status.OK.getStatusCode()) {
				String content = response.readEntity(String.class);
				if (!content.equals("")) {
					JsonElement element = jsonParser.parse(content);
					if (element.isJsonObject()) {
						return element.getAsJsonObject();
					} else if (element.isJsonArray()) {
						return element.getAsJsonArray();
					}
				}
			} else {
				if (printErrResponse) {
					String content = response.readEntity(String.class);
					logger.error("requestGET " + response.getStatus() + " " + content);
					logger.error("uri:" + uri);
				}
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("requestGET error:" + sw.toString());
		} finally {
			if (client != null) {
				client.close();
			}
		}
		return new JsonObject();
	}

	public JsonObject requestPOST(String uri, MultivaluedMap<String, Object> headerData, String postData) {
		return requestPOST(uri, headerData, postData, get_connection_conf(), false).getAsJsonObject();
	}

	/**
	 *
	 * @param uri
	 * @param headerData
	 *            default json in get_header()
	 * @param conf
	 *            default in get_connection_conf()
	 * @param printErrResponse
	 *            if not Status.OK.getStatusCode()
	 * @return
	 */
	public synchronized JsonElement requestPOST(String uri, MultivaluedMap<String, Object> headerData, String postData, ClientConfig conf, boolean printErrResponse) {
		Client client = null;
		try {
			client = ClientBuilder.newClient(conf);
			WebTarget webTarget = client.target(uri);
			Invocation.Builder builder = webTarget.request(MediaType.APPLICATION_JSON_TYPE);
			if (headerData != null) {
				builder.headers(headerData);
			}
			Response response = builder.post(Entity.json(postData));

			if (response.getStatus() == Status.OK.getStatusCode()) {
				String content = response.readEntity(String.class);
				if (!content.equals("")) {
					JsonElement element = jsonParser.parse(content);
					if (element.isJsonObject()) {
						return element.getAsJsonObject();
					} else if (element.isJsonArray()) {
						return element.getAsJsonArray();
					}
				}
			} else {
				if (printErrResponse) {
					String content = response.readEntity(String.class);
					logger.error("requestPOST " + response.getStatus() + " " + content);
					logger.error("uri:" + uri);
				}
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("requestPOST error:" + sw.toString());
		} finally {
			if (client != null) {
				client.close();
			}
		}
		return new JsonObject();
	}

	public JsonArray IgniteRemoteRestQuery(String CacheName, String sql, String igniteRest) {
		return IgniteRemoteRestQuery(CacheName, sql, igniteRest, 1000);
	}

	public JsonArray IgniteRemoteRestQuery(String CacheName, String sql, String igniteRest, int pageSize) {
		long start = System.currentTimeMillis();
		logger.info("CacheName:" + CacheName + "|igniteRest:" + igniteRest);
		String script = "";
		JsonArray jsonArrayOutput = new JsonArray();
		try {
			script = URLEncoder.encode(sql, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}

		String uri = igniteRest + "/ignite?" + "cmd=qryfldexe&" + "pageSize=" + pageSize + "&" + "cacheName=" + CacheName + "&" + "qry=" + script;

		try {
			jsonArrayOutput = igniteUniversalQuery(uri);

			takeExecutionTime(start, "IgniteRemoteRestQuery", uri);
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("IgniteRemoteRestQuery error:" + sw.toString());
		}
		return jsonArrayOutput;
	}

	public JsonArray igniteUniversalQuery(String uri) throws Exception {
		JsonArray jsonArrayOutput = new JsonArray();
		String error = null;
		try {
			JsonObject jsonData = requestGET(uri, header).getAsJsonObject();

			if (jsonData.get("response").isJsonNull() && !jsonData.get("error").isJsonNull()) {
				error = jsonData.get("error").getAsString();
			} else {
				JsonObject response = jsonData.get("response").getAsJsonObject();
				JsonArray header = response.get("fieldsMetadata").getAsJsonArray();
				JsonArray data = response.get("items").getAsJsonArray();
				for (JsonElement item : data) {
					if (!item.isJsonArray()) {
						return data;
					}
					JsonArray ar = item.getAsJsonArray();
					JsonObject jo = new JsonObject();
					for (int i = 0; i < header.size(); i++) {
						JsonObject hd = header.get(i).getAsJsonObject();
						String fieldName = hd.get("fieldName").getAsString().toLowerCase();
						jo.add(fieldName, ar.get(i));
					}
					jsonArrayOutput.add(jo);
				}

				if (uri.contains("cmd=qryfldexe")) {
					String queryId = response.get("queryId").getAsString();
					if (queryId != null) {
						if (!IgniteRemoteRestQueryClose(queryId, uri.split("/ignite?")[0])) {
							logger.error("IgniteRemoteRestQueryClose failed , queryId : " + queryId);
						}
					} else {
						logger.error("queryId is null");
					}
				}

			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("universalQuery error:" + sw.toString());
		}
		if (error != null) {
			throw new Exception(error);
		}
		return jsonArrayOutput;
	}

	public String IgniteRemoteRestGet(String CacheName, String key, String igniteRest) {
		long start = System.currentTimeMillis();

		logger.info("CacheName:" + CacheName + "|igniteRest:" + igniteRest);
		String Output = "";

		try {
			key = URLEncoder.encode(key, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}

		String uri = igniteRest + "/ignite?" + "cmd=get&" + "cacheName=" + CacheName + "&" + "key=" + key;

		JsonObject jsonData = requestGET(uri, null).getAsJsonObject();

		try {
			JsonObject jsonResponse;
			try {
				jsonResponse = jsonData.get("response").getAsJsonObject();
			} catch (Exception e) {
				return jsonData.get("response").isJsonNull() ? "" : jsonData.get("response").getAsString();
			}
			Output = jsonResponse.isJsonNull() ? "" : jsonResponse.toString();

			takeExecutionTime(start, "IgniteRemoteRestGet", uri);
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("IgniteRemoteRestGet error:" + sw.toString());
		}
		return Output;
	}

	public boolean IgniteRemoteRestQueryClose(String qryId, String igniteRest) {
		boolean rtn = false;
		String uri = igniteRest + "/ignite?" + "cmd=qrycls&" + "qryId=" + qryId;

		JsonObject jsonData = requestGET(uri, null).getAsJsonObject();

		try {
			String responseString = jsonData.get("response").getAsString();
			if (responseString != null && responseString.equalsIgnoreCase("true")) {
				rtn = true;
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.warn("IgniteRemoteRestQueryClose error:" + sw.toString());
		}
		return rtn;
	}

	public void takeExecutionTime(long start, String method, String target) {
		double executionTime = Double.parseDouble(fmt.format((System.currentTimeMillis() - start) / 1000d));
		if (executionTime > 10) {
			logger.warn(method + " execution time is too long. executionTime:" + executionTime + " on " + target);
		} else {
			logger.info(method + " execution time:" + executionTime);
		}
	}

	public String getParentItem(String mktplsItemnumber) {
		long start = System.currentTimeMillis();
		String pn = "";

		String postData = "{\"Action\":\"SolrQuery\"," + "\"EntityType\":\"Newegg.BigData.Entity.ItemMaintain.Solr.ItemBaseSolrEntity\"," + "\"FieldList\":[\"ParentItem\"]," + "\"IndexFilter\":\"ItemNumber:" + mktplsItemnumber + "\"," + "\"SorlSearchResultType\":\"EntityList\"," + "\"PageSize\":10," + "\"PageIndex\":0," + "\"SolrSearchWT\":\"json\","
				+ "\"SerializeType\": \"JsonSerializeProvider\",\"ResultValueType\":\"ResultEntity\"}";
		JsonObject iteminfo = requestPOST(bigdata_api_uri, header, postData);
		if (iteminfo.get("ResultValue") != null) {
			// [{"ParentItem":"20-147-373"}]
			JsonArray itemList = iteminfo.get("ResultValue").getAsJsonArray();
			if (itemList.size() > 0) {
				JsonElement item = itemList.get(0);
				pn = ((JsonObject) item).get("ParentItem").getAsString();
			}
		}

		takeExecutionTime(start, "getParentItem", postData);
		return pn;
	}

	public JsonElement commonAPICommission(String url) {
		String content = "";
		Client client = null;
		try {
			client = ClientBuilder.newClient(get_connection_conf());

			WebTarget webTarget = client.target(url);
			Invocation.Builder builder = webTarget.request(MediaType.APPLICATION_JSON_TYPE);
			builder.headers(header);
			Response response = builder.get();

			content = response.readEntity(String.class);
			// InputStream inputStream = response.readEntity(InputStream.class);
			// BufferedReader in = null;
			// in = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
			// content = in.readLine();

			if (response.getStatus() == Status.OK.getStatusCode()) {
				JsonObject jsonResponse = jsonParser.parse(content).getAsJsonObject();
				String status = jsonResponse.get("status").getAsString();
				if (status.equalsIgnoreCase("success")) {
					return jsonResponse.get("data").getAsJsonArray();
				}
			} else {
				logger.error("url:" + url);
				logger.error("content:" + content);
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error("url:" + url);
			logger.error("content:" + content);
			logger.error(sw.toString());
		} finally {
			if (client != null) {
				client.close();
			}
		}
		return null;
	}

	public static void main(String[] args) {
		String url = "http://apis-e11k.newegg.org/bi/estimate/get_estimated_commission?isINTL=No&countryCode=CAN&sellerID=aetr&industryCode=CH&subcategoryID=152&itemNumber=9SIAETRB9B9101&soDate=2021-03-09";
		JsonElement result = new RestClient(HeaderFactory.build(null, "bi-test")).commonAPICommission(url);
		System.out.println(StringUtils.toGson(result));
	}

	public static JsonObject requestPOST(URI uri, String serviceName, String requestBody) {

		try {
			HttpResponse httpResponse = Request.Post(uri)
					.addHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
					.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
					.addHeader("ServiceName",serviceName)
					.connectTimeout(300 * 1000)
					.socketTimeout(300 * 1000)
					.bodyString(requestBody, ContentType.APPLICATION_OCTET_STREAM)
					.execute().returnResponse();

			if (httpResponse != null) {
				String responseString = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
				JsonObject jsonObject = new JsonParser().parse(responseString).getAsJsonObject();
				return jsonObject;
			}

		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}

		return null;
	}

}
