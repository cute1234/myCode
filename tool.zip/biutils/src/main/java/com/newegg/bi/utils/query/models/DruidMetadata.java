package com.newegg.bi.utils.query.models;

public class DruidMetadata {
	public DruidMetadata(){}
	public DruidMetadata(String column_name,String column_type,Boolean is_dimension){
		this.column_type=column_type;
		this.column_name=column_name;
		this.is_dimension=is_dimension;
	}
	public String column_type="String";
	public String column_name="";
	public Boolean is_dimension=false;
	@Override
	public String toString(){
		return "column_name : "+this.column_name+" , column_type : "+this.column_type+" , is_dimension: "+this.is_dimension.toString();
	}
}
