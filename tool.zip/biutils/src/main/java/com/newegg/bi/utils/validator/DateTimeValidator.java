package com.newegg.bi.utils.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DateTimeValidator implements ConstraintValidator<DateTime, String> {
	 private DateTime dateTime;
    /**
     * initialize
     * @param dateTime
     */
    @Override
    public void initialize(DateTime dateTime) {
        this.dateTime = dateTime;
    }
    
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null) {
            return true;
        }
		String format = dateTime.format();
        if (value.length() != format.length()) {
            return false;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        simpleDateFormat.setLenient(false);
        try {
        	Date tmp=  simpleDateFormat.parse(value);
        } catch (Exception e) {
            return false;
        }
        return true;
	}

}
