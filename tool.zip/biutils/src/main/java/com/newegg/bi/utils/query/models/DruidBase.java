package com.newegg.bi.utils.query.models;


import com.google.gson.annotations.SerializedName;

public class DruidBase{
	@SerializedName("version")
	private String version;
	@SerializedName("timestamp")
	private String timestamp;
	@SerializedName("total_views")
	private String total_views;
	
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getTotal_views() {
		return total_views;
	}
	public void setTotal_views(String total_views) {
		this.total_views = total_views;
	}
	

	
}
