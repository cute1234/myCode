package com.newegg.bi.utils.common;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.lang.reflect.Type;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by Dara.L.Huang on 8/1/2018.
 * Email : Dara.L.Huang@newegg.com
 */
public class StringUtils {

    private static Logger logger = Logger.getLogger(StringUtils.class);

    private static ObjectMapper jsonMapper = new ObjectMapper();
    private static Gson gson = new Gson();
    private static JsonParser jsonParser = new JsonParser();
    private static final ObjectMapper OBJECT_MAPPER;

    static {
        jsonMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        OBJECT_MAPPER = new ObjectMapper();
    }

    /*
    json method
     */

    public static <T> T readJSON(String jsonString, Class<T> clazz) {
        if (jsonString != null) {
            try {
                return jsonMapper.readValue(jsonString, clazz);
            } catch (Exception e) {
                logger.error("jsonMapper error:" + e.getMessage());
            }
        }
        return null;
    }

    public static <T> List<T> readJSON(String jsonString, TypeReference<List<T>> typeReference) {
        if (jsonString != null) {
            try {
                return jsonMapper.readValue(jsonString, typeReference);
            } catch (Exception e) {
            }
        }
        return null;
    }

    public static <T> T readJSON(Object object, Class<T> clazz) {
        return jsonMapper.convertValue(object, clazz);
    }

    /*
     * object to Json string
     *
     */
    public static String writeJSON(Object object) {
        if (object == null) {
            return null; // else JSON_MAPPER.writeValueAsString(object) will return "null"
        }
        try {
            return jsonMapper.writeValueAsString(object);
        } catch (Exception e) {
            logger.error("jsonMapper error:" + e.getMessage());
        }
        return null;
    }

    /*
    gson method
     */

    public static String toGson(Object o) {
        return gson.toJson(o);
    }

    public static <T> T fromGson(String str, Type type) {
        return gson.fromJson(str, type);
    }

    public static JsonObject fromGson(String json) {
        return jsonParser.parse(json).getAsJsonObject();
    }

    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    public static String null2Empty(String str) {
        return isEmpty(str) ? "" : str;
    }
    private static String SQLType2JavaTypeInString(String source_type) {
		String java_type = null;
		if (source_type.startsWith("money") || source_type.startsWith("decimal") || source_type.startsWith("smallmoney")) {
			java_type = "double";
		} else if (source_type.startsWith("numeric")) {
			java_type = "bigdecimal";
		} else if (source_type.startsWith("int") || source_type.startsWith("smallint") || source_type.startsWith("tinyint") || source_type.startsWith("bit")) {
			java_type = "integer";
		} else if (source_type.startsWith("bigint")) {
			java_type = "long";
		} else if (source_type.startsWith("real") || source_type.startsWith("float")) {
			java_type = "float";
		} else if (source_type.startsWith("varchar") || source_type.startsWith("longvarchar") || source_type.startsWith("character") || source_type.startsWith("nvarchar") || source_type.startsWith("char") || source_type.startsWith("nchar") || source_type.startsWith("text") || source_type.startsWith("ntext") || source_type.startsWith("uniqueidentifier") || source_type.startsWith("sysname")) {
			java_type = "string";
		} else if (source_type.startsWith("date") || source_type.startsWith("datetime") || source_type.startsWith("datetime2") || source_type.startsWith("time") || source_type.startsWith("smalldatetime")) {
			java_type = "date";
		}
		return java_type;
	}

	public static JsonObject sqlResultToJsonObject(ResultSet res, ResultSetMetaData resultSetMetaData) throws SQLException {
		JsonObject object = new JsonObject();
		for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
			String columnName = resultSetMetaData.getColumnName(i);

			if (res.getString(columnName) != null) {
				String java_type = StringUtils.SQLType2JavaTypeInString(resultSetMetaData.getColumnTypeName(i));
				if (java_type.equals("double")) {
					object.addProperty(columnName, res.getDouble(columnName));
				} else if (java_type.equals("bigdecimal")) {
					object.addProperty(columnName, res.getBigDecimal(columnName));
				} else if (java_type.equals("integer")) {
					object.addProperty(columnName, res.getInt(columnName));
				} else if (java_type.equals("long")) {
					object.addProperty(columnName, res.getLong(columnName));
				} else if (java_type.equals("float")) {
					object.addProperty(columnName, res.getFloat(columnName));
				} else if (java_type.equals("string")) {
					object.addProperty(columnName, res.getString(columnName).trim());
				} else if (java_type.equals("date")) {
					object.addProperty(columnName, res.getTimestamp(columnName).getTime());
				} else {
					object.addProperty(columnName, res.getString(columnName).trim());
				}
			}

		}
		return object;
	}

    public static <T> String serialize(T t) {
        try {
            return OBJECT_MAPPER.writeValueAsString(t);
        } catch (IOException e) {
            logger.error("SerializeUtils serialize " + t + " exception: " + e.toString());
            throw new RuntimeException(e);
        }
    }
}
