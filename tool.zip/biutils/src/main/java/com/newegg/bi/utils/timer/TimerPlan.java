package com.newegg.bi.utils.timer;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

public class TimerPlan {
	private Timer timer = new Timer();
	private int hr;
	private int min;
	private int sec;

	public TimerPlan(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		this.hr = calendar.get(Calendar.HOUR_OF_DAY);
		this.min = calendar.get(Calendar.MINUTE);
		this.sec = calendar.get(Calendar.SECOND);
	}

	public Timer getTimer() {
		return timer;
	}

	public void setTimer(Timer timer) {
		this.timer = timer;
	}

	public int getHr() {
		return hr;
	}

	public void setHr(int hr) {
		this.hr = hr;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getSec() {
		return sec;
	}

	public void setSec(int sec) {
		this.sec = sec;
	}
}
