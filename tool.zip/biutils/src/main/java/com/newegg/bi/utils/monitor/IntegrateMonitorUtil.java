package com.newegg.bi.utils.monitor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.newegg.bi.utils.common.DateUtils;
import com.newegg.bi.utils.common.StringUtils;
import com.newegg.bi.utils.http.client.RestClient;

/**
 * 各service的monitor集成傳入，以及獲得monitor center的status回傳
 * <p>從0.0.33開始支援
 * @author gk18
 * @version 1.0.0
 * @since 4/19/2022
 * @see 
 */
public class IntegrateMonitorUtil {
	private final static String BASE_MONITOR_URI="%s/bi/monitorcenter/";
	private final static String QUERYACTIVESTATUS_URl =BASE_MONITOR_URI+"query/queryJobActiveStatus?";
	private final static String QUERYACTIVESTATUS_PARAMETER_URL  =QUERYACTIVESTATUS_URl+"mointorService=%s&mointorType=%s&mointorJob=%s";
	private final static String RECEIVE_URl =BASE_MONITOR_URI+"receive/receiveMointor/";
	private final static String RECEIVE_PARAMETER_URl =RECEIVE_URl+"%s/%s/%s";
	
	/**
	 * set entity的值，做為測試用途，因此Deprecated
	 * @param entity
	 * @param type
	 * @param service
	 * @param jobName
	 * @param url
	 * @param status
	 * @return
	 */
	@Deprecated
	private IntegrateMonitorEntity monitorCenterCover(Object entity,String type,String service,String jobName,List<String> url,boolean status) {
		//new 物件
		IntegrateMonitorEntity integrateMonitorEntity = new IntegrateMonitorEntity();
		//寫入回傳的Entity
		integrateMonitorEntity.setResponse(entity);
		integrateMonitorEntity.setProcessDateTime(DateUtils.getDateTime(DateUtils.dateFormatStr));
		integrateMonitorEntity.setStatus(status);
		integrateMonitorEntity.setType(type);
		integrateMonitorEntity.setService(service);
		integrateMonitorEntity.setJobName(jobName);
		//由於會有多條url，因此傳入為List
		integrateMonitorEntity.setReference(url);
		//回傳的物件
		return integrateMonitorEntity;
		
	}
	private String getSite(String service) {
		if (StringUtils.isEmpty(service)) {
			return "";
		}
		switch (service) {
		case "GQC":
			return "http://sandboxapis.newegg.org";
		case "PRD":
			return  "http://apis.newegg.org";
		default:
			return "";
		}
	}
	/**
	 * 
	 * @param server 必填
	 * @param type   必填
	 * @param job    必填
	 * @param url    必填 
	 * @return
	 */
	private boolean isParameterNotEmpty(String server,String type,String job,String url) {		
		if (!StringUtils.isEmpty(type) && !StringUtils.isEmpty(job)
				&& !StringUtils.isEmpty(server) && !StringUtils.isEmpty(url)) {
			return true;
		}	
		return false;
	}
	/**
	 * 將set為IntegrateMonitorEntity值傳入monitor center
	 * @param entity
	 * @param url
	 * @return IntegrateMonitorResopnseEntity
	 */
	public IntegrateMonitorResopnseEntity callMonitor(IntegrateMonitorEntity entity,String service) {
		IntegrateMonitorResopnseEntity resopnseEntity = null;		
		//header目前為空
		MultivaluedMap<String, Object> headerData = null;
		//輸入url
		String url =getSite(service.toUpperCase());
		boolean parameterIsNotEmpty = isParameterNotEmpty(entity.getService(),entity.getType(),entity.getJobName(),url);
		//任一參數是空的，就直接返回，不做事情
		if (parameterIsNotEmpty) {			
			resopnseEntity = new  IntegrateMonitorResopnseEntity();
			headerData = new MultivaluedHashMap<String, Object>();			
			RestClient client = new RestClient(headerData);
			String monitorUri = String.format(RECEIVE_PARAMETER_URl, url, entity.getService(), entity.getType(),
					entity.getJobName());
			// 轉為String 寫入monitor center
			JsonElement jsonPostData = client.requestPOST(monitorUri, headerData,
					StringUtils.writeJSON(entity), client.get_connection_conf(60,60), false);
			// 寫入值
			resopnseEntity.setProcessDateTime(DateUtils.getDateTime(DateUtils.dateFormatStr));
			resopnseEntity.setStatus(true);
			// 還是一樣給網址
			resopnseEntity.setReference(entity.getReference());
			resopnseEntity.setResponse(StringUtils.toGson(jsonPostData));
			// requestPOST會return object或array
			if (jsonPostData.isJsonObject()) {
				if (((JsonObject) jsonPostData).size() == 0) {
					resopnseEntity.setStatus(false);
				}
			} else if (jsonPostData.isJsonArray()) {
				if (((JsonArray) jsonPostData).size() == 0) {
					resopnseEntity.setStatus(false);
				}
			}
			client = null;
			jsonPostData = null;
			
		}
		return resopnseEntity;
	}
	
	/**
	 * 將set為IntegrateMonitorEntity多筆的值傳入monitor center
	 * @param entity
	 * @param url
	 * @return List IntegrateMonitorResopnseEntity
	 */
	public List<IntegrateMonitorResopnseEntity> callMonitor(List<IntegrateMonitorEntity> entity,String url) {		
		List<IntegrateMonitorResopnseEntity> resopnseList = new ArrayList<>();
		IntegrateMonitorResopnseEntity resopnseEntity = null;
		for(IntegrateMonitorEntity oneEntity:entity) {
			resopnseEntity=callMonitor(oneEntity,url);
			resopnseList.add(resopnseEntity);
		}	
		return resopnseList;
	}
	/**
	 * 回傳monitorcenter內該api的status和時間
	 * @param entity
	 * @param url
	 * @return monitorActiveEntity
	 */
	public MonitorActiveEntity queryActive(String server,String type,String jobName, String service) {		
		MonitorActiveEntity monitorActiveEntity = null;
		String site =getSite(service.toUpperCase());
		boolean parameterIsNotEmpty = isParameterNotEmpty(server,type,jobName,site);
		if (parameterIsNotEmpty) {
			RestClient restClient = new RestClient(null);
			monitorActiveEntity = new MonitorActiveEntity();
			String queryUri = String.format(QUERYACTIVESTATUS_PARAMETER_URL,site,server,type,jobName);
			JsonElement queryJson = restClient.requestGET(queryUri, null);
			JsonObject queryObject = queryJson.getAsJsonObject();
			// 取得在api(query)內的active
			monitorActiveEntity = StringUtils.fromGson(queryObject.toString(), MonitorActiveEntity.class);
			
			//清空物件
			restClient = null;
			queryJson = null;
			queryObject = null;
		} 
		return monitorActiveEntity;

	}

	//測試用
	public static void main(String[] args) {
		IntegrateMonitorEntity integrateMonitor = new IntegrateMonitorEntity();
		Map<String,String> map = new HashMap<String,String>();
		map.put("test", "test");
		List<String> list = new ArrayList<>();
		list.add("testUrl");
		integrateMonitor.setJobName("test");
		integrateMonitor.setProcessDateTime(DateUtils.getDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
		integrateMonitor.setReference(list);
		integrateMonitor.setResponse(map);
		integrateMonitor.setService("test");
		integrateMonitor.setStatus(true);
		integrateMonitor.setType("test");
		IntegrateMonitorUtil m = new IntegrateMonitorUtil();
		MonitorActiveEntity monitorActiveEntity = new MonitorActiveEntity();
		monitorActiveEntity = m.queryActive(integrateMonitor.getService(),integrateMonitor.getType(),integrateMonitor.getJobName(),"");
		System.out.println(StringUtils.toGson(monitorActiveEntity));
		String activeStatus = monitorActiveEntity.getActiveStatus();
		if(activeStatus.equals("active")) {
			System.out.println(activeStatus);
		}else {
			System.out.println(activeStatus);
		}
//		
//		try {
//			IntegrateMonitorResopnseEntity result = m.callMonitor(integrateMonitor, "GQC");	
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
			
		
		
		//查看callMonitor結果(為GET)
		//http://sandboxapis.newegg.org/bi/monitorcenter/query/queryMonitorResult?mointorType=test&mointorJob=test&limitSize=10&mointorService=test
		
	}
}
