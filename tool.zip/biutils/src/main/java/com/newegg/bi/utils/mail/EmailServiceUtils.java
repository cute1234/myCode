package com.newegg.bi.utils.mail;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;

import com.google.gson.JsonObject;
import com.newegg.bi.utils.common.JsonUtils;
import com.newegg.bi.utils.common.StringUtils;
import com.newegg.bi.utils.http.client.RestClient;

public class EmailServiceUtils {

	static Logger logger = Logger.getLogger(EmailServiceUtils.class);

	// private static String BI_ADMIN_MAIL = "sam.c.pai@newegg.com,jaden.c.cheng@newegg.com,wilson.w.tu@newegg.com,marco.r.ma@newegg.com";
	public static String BI_ADMIN_MAIL = "jaden.c.cheng@newegg.com,wilson.w.tu@newegg.com";
	public static String BI_SYSTEM_MAIL = "bi@newegg.com";

	private static String url = "http://apis.newegg.org/EmailService/Email";

	private static String authorization = "Bearer VsIgZ9r6YmkROyDrLiOr97RVHoMn2RxEbxNaT2DC";

	public static boolean sendMessage(EmailEntity email) {
		MultivaluedMap<String, Object> header = new MultivaluedHashMap<>();
		header.add("Accept", "application/json");
		header.add("Authorization", authorization);

		String postData = StringUtils.toGson(email);
		logger.info("postData:" + postData);
		try {
			RestClient client = new RestClient(null);
			JsonObject result = client.requestPOST(url, header, postData);
			if (JsonUtils.isJsonEmpty(result) || JsonUtils.isJsonEmpty(result.get("Status")) || result.get("Status").equals("false")) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			logger.error(sw.toString());
		}
		return false;
	}
	/**
	 * 寄送mail，Cc及Bcc可為空
	 * @param systemId
	 * @param countryCode
	 * @param mailTo
	 * @param mailCc
	 * @param mailBcc
	 * @param mailFrom
	 * @param subject
	 * @param body
	 */
	public static void sendMail(String systemId,String countryCode,String mailTo,String mailCc,String mailBcc,String mailFrom,String subject,String body) {
		
		EmailEntity emailEntity = new EmailEntity();
		//required
		emailEntity.setSystemID(systemId);//BI-RTM
		emailEntity.setCountryCode(countryCode);//USA
		emailEntity.setToName(mailTo);
		emailEntity.setFromName(mailFrom);
		emailEntity.setSubject(subject);//mail Title
		emailEntity.setBody(body);//mail context
		//optional
		emailEntity.setCcName(mailCc);
		emailEntity.setBccName(mailBcc);
		logger.info(StringUtils.toGson(emailEntity));
		logger.info(String.valueOf(sendMessage(emailEntity)));
	}

	public static void main(String[] args) {
		 EmailEntity emailEntity = new EmailEntity();
		 // required
		 emailEntity.setSystemID("BI-RTM-SPA-Reminder");
		 emailEntity.setCountryCode("USA");
		 emailEntity.setToName("Gary.S.Kao@newegg.com");
		 // optional
		 emailEntity.setCcName(null);
		 emailEntity.setBccName(null);
		 emailEntity.setFromName(BI_SYSTEM_MAIL);
		 emailEntity.setSubject("Test for SPA Reminder6");
		 emailEntity.setBody("hi~~~");

//		EmailEntity emailEntity = new EmailEntity();
//		// required
//		emailEntity.setSystemID("EGG1309001");
//		emailEntity.setCountryCode("USA");
//		emailEntity.setToName("wilson.w.tu@newegg.com");
//		// optional
//		emailEntity.setTemplateID("003658");
//		List<DataVariable> ds = new ArrayList<>();
//		ds.add(new DataVariable("#DV_MarketplaceSellerName#", "Wilson.w1"));
//		emailEntity.setDataVariables(ds);

		logger.info(String.valueOf(EmailServiceUtils.sendMessage(emailEntity)));
	}
}
