package com.newegg.bi.utils.logx;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.gson.JsonObject;
import com.newegg.bi.utils.common.JsonUtils;
import com.newegg.bi.utils.common.StringUtils;
import com.newegg.bi.utils.mail.EmailServiceUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import static com.newegg.bi.utils.http.client.RestClient.requestPOST;

public class LogXUtils {
    static Logger logger = Logger.getLogger(EmailServiceUtils.class);

    private static LogXUtils instance;

    public LogXUtils() {
        instance = this;
    }

    public static LogXUtils getInstance() {
        return instance;
    }

    public static <T> Boolean sendLogXMessage(String url, Integer logType, String logTypeName, List<T> entityList) {
        Boolean result = false;
        String message;

        try{
            URI uri = new URI(url);
            if (entityList != null && entityList.size() > 0)
            {
                LogXlogEntity logXlog;
                LogXRequest logXRequest = new LogXRequest();
                for (T entity : entityList)
                {
                    logXlog = (LogXlogEntity)entity;
                    logXlog.setLogType(logTypeName);
                    logXlog.setSeverityLevel(SeverityLevel.INFO.getValue());
                    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                    logXlog.setLogTimeStamp(timestamp.getTime());
                }
                logXRequest.setLogType(logType);
                logXRequest.setLog(entityList);
                String postData = StringUtils.serialize(logXRequest);
                JsonObject requestResult = requestPOST(uri, "service", postData);
                if (JsonUtils.isJsonEmpty(requestResult) || JsonUtils.isJsonEmpty(requestResult.get("status")) || !(requestResult.get("status").toString().equals("200"))) {
                    result = false;
                } else {
                    result= true;
                }
            }

        }catch(Exception ex){
            logger.error("sendLogXMessage Exception Message:"+ ExceptionUtils.getStackTrace(ex));
            result = false;
        }

        return result;
    }

}
