package com.newegg.bi.utils.query.models;

public class DruidDataSource {
	public static String page_view = "page_view";
	public static String page_view_expansion_v4 = "pageview-expansion-v4";
	public static String product_view = "product_view";
//	public static String products = "products"; //2020-11-12 cube 'products' switch to campaign product 
	public static String productsCampaign = "BI_Campaign_Product"; //2020-11-12 cube 'products' switch to campaign product 
	public static String add_to_cart = "add_to_cart";
	public static String products_withCampaign = "products_withCampaign";
	public static String key_metrics = "key_metrics";
	public static String key_metrics_tthigo = "key_metrics_tthigo";
	public static String so = "f_salesorderdetail_combine_witheimsandcampaign";

	public static String pageview_expansion_v4 = "pageview-expansion-v4";
	public static String itemsoldhistory_extend_combine = "f_itemsoldhistory_extend_combine";
	
}
