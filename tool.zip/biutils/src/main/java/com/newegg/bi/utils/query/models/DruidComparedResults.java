package com.newegg.bi.utils.query.models;


public class DruidComparedResults {
	private String fullTime;
	private String time;
	private Integer selected;
	private Integer compared;
	private Double growth;
	public String getFullTime() {
		return fullTime;
	}
	public void setFullTime(String fullTime) {
		this.fullTime = fullTime;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Integer getSelected() {
		return selected;
	}
	public void setSelected(Integer selected) {
		this.selected = selected;
	}
	public Integer getCompared() {
		return compared;
	}
	public void setCompared(Integer compared) {
		this.compared = compared;
	}
	public Double getGrowth() {
		return growth;
	}
	public void setGrowth(Double growth) {
		this.growth = growth;
	}
	
	
	
}

	
