package com.newegg.bi.utils.query.models;

import java.util.List;

public class QueryFieldsAggr {
	private String type;
	private String dimension;
	private String value;
	private Object extractionFn;
	private String pattern;
	private List<String> values;
	private QueryFieldsAggr field;

	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public Object getExtractionFn() {
		return extractionFn;
	}
	public void setExtractionFn(Object extractionFn) {
		this.extractionFn = extractionFn;
	}

	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	public List<String> getValues() {
		return values;
	}
	public void setValues(List<String> values) {
		this.values = values;
	}

	public QueryFieldsAggr getField() {
		return field;
	}
	public void setField(QueryFieldsAggr field) {
		this.field = field;
	}
	
	
	
	public QueryFieldsAggr(){}
	public QueryFieldsAggr(String type,String dimension,String value){
		this.type=type;
		this.dimension=dimension;
		this.value=value;
	}
	public QueryFieldsAggr(String type,String dimension,String value,Object extractionFn){
		this.type=type;
		this.dimension=dimension;
		this.value=value;
		this.extractionFn=extractionFn;
	}
	public QueryFieldsAggr(String type,String dimension,String value,Boolean isREG){
		this.type=type;
		this.dimension=dimension;
		this.pattern=value;
	}
	public QueryFieldsAggr(String type,String dimension,List<String> values){
		this.type=type;
		this.dimension=dimension;
		this.values=values;
	}

}
