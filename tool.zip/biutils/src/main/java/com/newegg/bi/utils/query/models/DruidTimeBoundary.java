package com.newegg.bi.utils.query.models;

import java.text.ParseException;
import java.util.Date;

import com.newegg.bi.utils.common.StringUtils;
import com.newegg.bi.utils.query.interval.IntervalDateUtils;

//UTC
public class DruidTimeBoundary {

	private String maxTime;
	private String minTime;

	public Date getMax() throws ParseException {
		if (StringUtils.isEmpty(maxTime)) {
			return new Date();
		} else {
			return IntervalDateUtils.getDate(maxTime, IntervalDateUtils.fmt_druid);
		}
	}

	public Date getMin() throws ParseException {
		if (StringUtils.isEmpty(maxTime)) {
			return new Date();
		} else {
			return IntervalDateUtils.getDate(minTime, IntervalDateUtils.fmt_druid);
		}
	}

	public String getMaxTime() {
		return maxTime;
	}

	public void setMaxTime(String maxTime) {
		this.maxTime = maxTime;
	}

	public String getMinTime() {
		return minTime;
	}

	public void setMinTime(String minTime) {
		this.minTime = minTime;
	}

	// public String getMaxTimeUSA() throws ParseException {
	// if (maxTime != null) {
	// return IntervalDateUtils.getUSAFromUTC(maxTime, IntervalDateUtils.fmt_druid);
	// } else {
	// return DateUtils.getDateTime(IntervalDateUtils.fmt_druid);
	// }
	// }

}
