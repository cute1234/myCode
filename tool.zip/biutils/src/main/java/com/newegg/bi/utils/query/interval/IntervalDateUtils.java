package com.newegg.bi.utils.query.interval;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.newegg.bi.utils.common.DateUtils;

public class IntervalDateUtils {

	public static String fmt_clickhouse = "yyyy-MM-dd HH:mm:ss";
	public static String fmt_clickhouse_day = "yyyy-MM-dd 00:00:00";

	public static String fmt_druid = "yyyy-MM-dd'T'HH:mm:ss.000";
	public static String fmt_druid_minute = "yyyy-MM-dd'T'HH:mm:00.000";
	public static String fmt_druid_hour = "yyyy-MM-dd'T'HH:00:00.000";
	public static String fmt_druid_day = "yyyy-MM-dd'T'00:00:00.000";

	public static Date getDate(String date, String fmt) throws ParseException {
		final SimpleDateFormat df = new SimpleDateFormat(fmt);
		return df.parse(date);
	}

	public static Date getDateBySeason(Date startDate, int seasonOffset) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.add(Calendar.MONTH, seasonOffset * 3);
		return calendar.getTime();
	}

	public static Date getSeasonStart(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);

		int month = calendar.get(Calendar.MONTH) + 1;
		int season = (int) Math.ceil(month / 3.0);

		calendar.set(Calendar.MONTH, (season - 1) * 3); // ex. q2 = (2-1)*3 = 3 (April)
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static int getSeason(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		int month = calendar.get(Calendar.MONTH) + 1;
		return (int) Math.ceil(month / 3.0);
	}

	public static Date getDateByMonth(Date startDate, int monthOffset) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.add(Calendar.MONTH, monthOffset);
		return calendar.getTime();
	}
	
	public static Date getDateStart(int offset,Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.add(Calendar.DATE, offset);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}
	
	public static Date getWeekStart(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);

		calendar.set(Calendar.DAY_OF_WEEK, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}
	
	public static Date getMonthStart(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);

		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static Date getLastDateByMonth(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.add(Calendar.MONTH, 1);
		calendar.add(Calendar.DATE, -1);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();

	}

	public static Date getLastDateBySeason(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		int month = calendar.get(Calendar.MONTH) + 1;
		int season = (int) Math.ceil(month / 3.0);

		calendar.set(Calendar.MONTH, (season - 1) * 3); // ex. q2 = (2-1)*3 = 3 (April)
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.add(Calendar.MONTH, 3);
		calendar.add(Calendar.DATE, -1);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}

	public static Date getYearStart(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.set(Calendar.MONTH, 0);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static Date getLastDateByYear(Date startDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.set(Calendar.MONTH, 11);
		calendar.set(Calendar.DAY_OF_MONTH, 31);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}

	public static Date getDateByYear(Date startDate, int yearOffset) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.add(Calendar.YEAR, yearOffset);
		return calendar.getTime();
	}

	public static Date getDateByOffset(Date startDate, int offsetDate) throws ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.add(Calendar.DATE, offsetDate);
		return calendar.getTime();
	}
	public static Date getDateByOffsetDynamic(Date startDate, int offset,String intervalType) throws ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		switch (intervalType.toLowerCase()) {
		case "date":
			calendar.add(Calendar.DATE, offset);
			break;
		case "week":
			calendar.add(Calendar.DATE, offset*7);
			break;
		case "month":
			calendar.add(Calendar.MONTH, offset);
			break;
		case "Quarter":
			calendar.add(Calendar.MONTH, offset*3);
			break;
		case "year":
			calendar.add(Calendar.YEAR, offset);
			break;
		default:
			System.out.println("not support this IntervalType:"+intervalType);
		}
		return calendar.getTime();
	}

	public static String getUTC(Date date, String fmtString) throws ParseException {
		SimpleDateFormat fmt = new SimpleDateFormat(fmtString);
		fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
		String curTime = fmt.format(date.getTime()).trim();
		return curTime;
	}
	
	public static String getUSA(Date date, String fmtString) throws ParseException {
		SimpleDateFormat fmt = new SimpleDateFormat(fmtString);
		fmt.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
		String curTime = fmt.format(date.getTime()).trim();
		return curTime;
	}

	public static String getDate(Date date, String fmtString) throws ParseException {
		SimpleDateFormat fmt = new SimpleDateFormat(fmtString);
		String curTime = fmt.format(date.getTime()).trim();
		return curTime;
	}

//	public static String getUSAFromUTC(String startDateString, String fmtString) throws ParseException {
//		SimpleDateFormat fmt = new SimpleDateFormat(fmtString);
//		fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
//
//		Date date = fmt.parse(startDateString);
//
//		fmt.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
//		String curTime = fmt.format(date.getTime()).trim();
//		return curTime;
//	}

}
