package com.newegg.bi.utils.monitor;

public enum EventNoticeEnum {
	BI_RTM_TEAM("brock.x.lin@newegg.com;jaden.c.cheng@newegg.com;Gary.S.Kao@newegg.com"),
	BI_RTM_TEAM_WITH_PDT("brock.x.lin@newegg.com;jaden.c.cheng@newegg.com;Gary.S.Kao@newegg.com;Sam.C.Pai@newegg.com;Mark.P.Fan@newegg.com"),
	BI_Clayton_TEAM("Clayton.Y.Yan@newegg.com;Victor.C.Chen@newegg.com;Neddy.Y.Wang@newegg.com;Susan.Y.Zhang@newegg.com");

	EventNoticeEnum(String ownerEmail){
		this.ownerEmail=ownerEmail;
	}
	private String ownerEmail;
	public String getOwnerEmail() {
		return ownerEmail;
	}
	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}
}
