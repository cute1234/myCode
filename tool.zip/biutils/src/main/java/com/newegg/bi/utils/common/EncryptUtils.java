package com.newegg.bi.utils.common;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class EncryptUtils {
	private static EncryptUtils instance = new EncryptUtils();
	private Cipher cipherEncrypt;
	private Cipher cipherDecrypt;
	private Key key;

	synchronized public static EncryptUtils getInstance() {
		return EncryptUtils.instance;
	}

	private EncryptUtils() {

		try {
			this.cipherEncrypt = Cipher.getInstance("AES");
			this.cipherDecrypt = Cipher.getInstance("AES");
			byte[] raw = { (byte) 0xA5, (byte) 0x01, (byte) 0x7B, (byte) 0xE5, (byte) 0x23, (byte) 0xCA, (byte) 0xD4, (byte) 0xD2, (byte) 0xC6, (byte) 0x5F, (byte) 0x7D, (byte) 0x8B, (byte) 0x0B, (byte) 0x9A, (byte) 0x3C, (byte) 0xF1 };
			this.key = new SecretKeySpec(raw, "AES");
			cipherEncrypt.init(Cipher.ENCRYPT_MODE, key);
			cipherDecrypt.init(Cipher.DECRYPT_MODE, key);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {

		}
	}

	public String encrypt(String aData) {
		String result = "";
		try {
			byte[] utf8 = aData.getBytes("UTF8");
			byte[] encryptedData = cipherEncrypt.doFinal(utf8);
			result = org.apache.commons.codec.binary.Base64.encodeBase64String(encryptedData);// this.b64Encoder.encode(encryptedData);
		} catch (IllegalBlockSizeException oException) {
			oException.printStackTrace();
		} catch (BadPaddingException oException) {
			oException.printStackTrace();
		} catch (IOException oException) {
			oException.printStackTrace();
		}
		return result;
	}

	public String decrypt(String aData) {
		String result = "";
		try {
			byte[] decodedData = org.apache.commons.codec.binary.Base64.decodeBase64(aData);// this.b64Decoder.decodeBuffer(aData);
			byte[] utf8 = cipherDecrypt.doFinal(decodedData);
			result = new String(utf8, "UTF8");
		} catch (IllegalBlockSizeException oException) {
			oException.printStackTrace();
		} catch (BadPaddingException oException) {
			oException.printStackTrace();
		} catch (UnsupportedEncodingException oException) {
			oException.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) {
		String password = "sparkrealtime";
		String passwordEncrypt = EncryptUtils.getInstance().encrypt(password);
		System.out.println(passwordEncrypt);
		System.out.println(EncryptUtils.getInstance().decrypt(passwordEncrypt));
	}

}
