package com.newegg.bi.utils.db.entity;

public class SqlBuilder {
	private Boolean allowNonWhereStatement;
	private SelectStatement select;
	private From from;
	private WhereStatement where;
	private GroupBy groupBy;
	private OrderBy orderBy;
	public SqlBuilder() {
		//預設為false，不允許沒有where 的sql 
		this.allowNonWhereStatement=false;
	}
	/**
	 * allowNonWhereStatement 是否允許空的where 預設為false 
	 * @param allowNonWhereStatement
	 */	
	public SqlBuilder(boolean allowNonWhereStatement) {
		this.allowNonWhereStatement=allowNonWhereStatement;
	}
	/**
	 * 產生查詢的sql
	 * @return
	 */
	public String buildSqlStatement() {
		return buildSqlStatement(SqlFormatTypeEnum.SQL_FORMAT_TYPE_NON);
	}
	public String buildSqlStatement(SqlFormatTypeEnum formatType) {
		StringBuffer sb=new StringBuffer();
		sb.append(SqlEnum.SQL_PARENTHESES_S.getValue());
		if (null!=select) {
			sb.append(SqlEnum.SQL_SELECT.getValue()).append(SqlEnum.SQL_SPACE.getValue());
			sb.append(select.toStatement());
			sb.append(SqlEnum.SQL_SPACE.getValue());
		}
		if (null!=from) {
			sb.append(SqlEnum.SQL_FROM.getValue());				
			sb.append(from.toStatement());
			sb.append(SqlEnum.SQL_SPACE.getValue());
		}	
		
		if (null!=where) {
			sb.append(SqlEnum.SQL_WHERE.getValue());
			sb.append(where.toStatement(this.allowNonWhereStatement));
			
		}else {
			if (!allowNonWhereStatement) {
				sb.append(SqlEnum.SQL_WHERE.getValue());
				sb.append(" 1=2 ").append(SqlEnum.SQL_SPACE.getValue());
			}
		}
		sb.append(SqlEnum.SQL_SPACE.getValue());
		if (null!=groupBy) {
			sb.append(SqlEnum.SQL_GROUP_BY.getValue());			
			sb.append(groupBy.toStatement());
			sb.append(SqlEnum.SQL_SPACE.getValue());
		}		
		if (null!=orderBy) {
			sb.append(SqlEnum.SQL_ORDER_BY.getValue());			
			sb.append(orderBy.toStatement());
		}
		sb.append(SqlEnum.SQL_PARENTHESES_E.getValue());
		if (null!=formatType) {
			sb.append(SqlEnum.SQL_SPACE.getValue());
			sb.append(formatType.getValue());
		}
		return sb.toString();
	}
	
	public SelectStatement getSelect() {
		return select;
	}
	public void setSelect(SelectStatement select) {
		this.select = select;
	}
	public From getFrom() {
		return from;
	}
	public void setFrom(From from) {
		this.from = from;
	}
	public WhereStatement getWhere() {
		return where;
	}
	public void setWhere(WhereStatement where) {
		this.where = where;
	}
	public GroupBy getGroupBy() {
		return groupBy;
	}
	public void setGroupBy(GroupBy groupBy) {
		this.groupBy = groupBy;
	}
	public OrderBy getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(OrderBy orderBy) {
		this.orderBy = orderBy;
	}
	
	
	
	
}
