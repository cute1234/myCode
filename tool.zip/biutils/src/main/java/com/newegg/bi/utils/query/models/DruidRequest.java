package com.newegg.bi.utils.query.models;


public class DruidRequest {
	private String measure;
	private String website;
	private String pageName;
	private String channel;	
	private String prop11;	
	private String time;
	private String evar15;
	private String compare;
	public String getMeasure() {
		return measure;
	}
	public void setMeasure(String measure) {
		this.measure = measure;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getProp11() {
		return prop11;
	}
	public void setProp11(String prop11) {
		this.prop11 = prop11;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getEvar15() {
		return evar15;
	}
	public void setEvar15(String evar15) {
		this.evar15 = evar15;
	}
	public String getCompare() {
		return compare;
	}
	public void setCompare(String compare) {
		this.compare = compare;
	}

	
}

	
