package com.newegg.bi.utils.query.interval;

public enum IntervalType {
	//current
	currentL1D,
	currentL7D,
	currentL14D,
	currentL30D,
	currentLYD,
	currentDay,
	currentWTD,
	currentMTD,
	currentQTD,
	currentYTD,
	
	//budget
	currentMonth,
	currentQuarter,
	currentYear,
	
	//comparison
	comparisonWithWoW,
	comparisonWithMoM,
	comparisonWithMoMMTD,
	comparisonWithQoQ,
	comparisonWithQoQQTD,
	comparisonWithYoY,
	comparisonWithYoYYTD,
	comparisonWithYoYMTD,
	comparisonWithYoYQTD,
	
	//dynamic
	dynamicInterVal,

	//previous
	previous1D,
	previous7D,
	previous30D,
	comparisonWithP1D,
	comparisonWithP7D,
	comparisonWithP30D

}
