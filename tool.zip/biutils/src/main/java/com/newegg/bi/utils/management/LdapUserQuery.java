package com.newegg.bi.utils.management;

/**
 * Created by Dara.L.Huang on 5/7/2019.
 * Email : Dara.L.Huang@newegg.com
 */
public class LdapUserQuery {

    private String UserName;
    private String RoleName;
    private String UserId;

    public LdapUserQuery() {
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getRoleName() {
        return RoleName;
    }

    public void setRoleName(String roleName) {
        RoleName = roleName;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }
}
