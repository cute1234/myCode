package com.newegg.bi.utils.check;

public interface Factor {

	boolean check();
}