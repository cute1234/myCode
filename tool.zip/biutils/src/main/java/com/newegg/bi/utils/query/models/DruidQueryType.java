package com.newegg.bi.utils.query.models;

public class DruidQueryType {
	public static String timeseries="timeseries";
	public static String groupBy="groupBy";
	public static String topN="topN";
}
