package com.newegg.bi.utils.db.entity;

import java.util.ArrayList;
import java.util.List;

public class From {
	private String table;
	public From(String table) {
		this.table=table;
	}
	
	public String toStatement() {

		return table;
	}
}
