package com.newegg.bi.utils.query.interval;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.newegg.bi.utils.common.DateUtils;
import com.newegg.bi.utils.query.models.DruidTimeBoundary;
import com.newegg.bi.utils.query.models.QueryContract;

/**
 * provide corporate query called
 *
 * @author wt8p
 */
public class IntervalFactory {
    QueryContract contract;
    DruidTimeBoundary dailyDataTimeBoundary;

    public IntervalFactory(QueryContract contract,
                           DruidTimeBoundary dailyDataTimeBoundary) {
        this.contract = contract;
        if (dailyDataTimeBoundary == null)
            dailyDataTimeBoundary = new DruidTimeBoundary();
        this.dailyDataTimeBoundary = dailyDataTimeBoundary;
    }

    /**
     * provide druid/clickhouse script to use
     *
    // * @param object
    // * @param intervalContract
    // * @param contract
    // * @param dailyDataTimeBoundary : from data source 'f_itemsoldhistory_extend_combine', provide
     *                              currentMTD/currentQTD endTime to align
     * @return intervals<IntervalType, Interval>
     * @throws ParseException
     */
    public Intervals build() throws ParseException {
        Intervals intervals = new Intervals();
        // current
        intervals.put(contract.getIntervalCurrent().getIntervalType(),
                build(contract.getIntervalCurrent(), null));

        // comparison
        if (contract.getIntervalComparison() != null) {
            for (IntervalContract c : contract.getIntervalComparison()) {
                intervals.put(
                        c.getIntervalType(),
                        build(c, intervals.get(contract.getIntervalCurrent()
                                .getIntervalType())));
            }

        }
        return intervals;
    }

    public Interval build(IntervalContract contract, Interval currentDay)
            throws ParseException {
        Interval interval = new Interval();
        IntervalType type = contract.getIntervalType();
        interval.setIntervalType(type);
        Date start = new Date();
        Date end = new Date();
        String startTime4Clickhouse = "";
        String endTime4Clickhouse = "";
        String startTime4Druid = "";
        String endTime4Druid = "";
        String usaDateString = IntervalDateUtils.getUSA(start, "yyyy-MM-dd");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date udaDate = sdf.parse(usaDateString);

        // it isn't realtime cube, must to align druid data max time
        // Date druidMaxDate =
        // IntervalDateUtils.getDate(dailyDataTimeBoundary.getMaxTimeUSA(),
        // IntervalDateUtils.fmt_druid);
        Date druidMaxDate = dailyDataTimeBoundary.getMax();
       // System.out.println("druidMaxDate:"+druidMaxDate);
        int offset = 0;
        switch (type) {
            case currentDay:
                // start = DateUtils.getDateStart(0);
                start = IntervalDateUtils.getDateStart(0, druidMaxDate);
                end = druidMaxDate;
                break;
            case currentL1D:
                start = IntervalDateUtils.getDateStart(-1, druidMaxDate);
                end = druidMaxDate;
                break;
            case currentL7D:
                start = DateUtils.getDateStart(-7);
                end = IntervalDateUtils.getDateByOffset(currentDay.getEnd(), -7);
                break;
            case currentL14D:
                start = DateUtils.getDateStart(-14);
                end = IntervalDateUtils.getDateByOffset(currentDay.getEnd(), -14);
                break;
            case currentL30D:
                start = IntervalDateUtils.getDateByMonth(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateByMonth(currentDay.getEnd(), -1);
                break;
            case currentLYD:
                start = IntervalDateUtils.getDateByYear(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateByYear(currentDay.getEnd(), -1);
                break;
            case currentWTD:
                start = IntervalDateUtils.getWeekStart(druidMaxDate);
                end = druidMaxDate;
                break;
            case currentMTD:
                start = IntervalDateUtils.getMonthStart(druidMaxDate);
                end = druidMaxDate;
                break;
            case currentMonth:
                start = IntervalDateUtils.getMonthStart(druidMaxDate);
                end = IntervalDateUtils.getLastDateByMonth(druidMaxDate);
                break;
            case currentQTD: // not realtime
                start = IntervalDateUtils.getSeasonStart(druidMaxDate);
                end = druidMaxDate;
                break;
            case currentQuarter: // not realtime
                start = IntervalDateUtils.getSeasonStart(druidMaxDate);
                end = IntervalDateUtils.getLastDateBySeason(druidMaxDate);
                break;
            case currentYTD: // not realtime
                start = IntervalDateUtils.getYearStart(druidMaxDate);
                end = druidMaxDate;
                break;

            case currentYear: // not realtime
                start = IntervalDateUtils.getYearStart(druidMaxDate);
                end = IntervalDateUtils.getLastDateByYear(druidMaxDate);
                break;
            case comparisonWithWoW:
                offset = -7;
                start = IntervalDateUtils.getDateByOffset(currentDay.getStart(),
                        offset);
                end = IntervalDateUtils
                        .getDateByOffset(currentDay.getEnd(), offset);
                break;
            case comparisonWithMoM:
                offset = -7 * 4;
                start = IntervalDateUtils.getDateByOffset(currentDay.getStart(),
                        offset);
                end = IntervalDateUtils
                        .getDateByOffset(currentDay.getEnd(), offset);
                break;
            case comparisonWithQoQ:
                offset = -7 * 12;
                start = IntervalDateUtils.getDateByOffset(currentDay.getStart(),
                        offset);
                end = IntervalDateUtils
                        .getDateByOffset(currentDay.getEnd(), offset);
                break;
            case comparisonWithYoY:
                offset = -365;
                start = IntervalDateUtils.getDateByOffset(currentDay.getStart(),
                        offset);
                end = IntervalDateUtils
                        .getDateByOffset(currentDay.getEnd(), offset);
                break;
            case comparisonWithMoMMTD:
                start = IntervalDateUtils.getDateByMonth(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateByMonth(currentDay.getEnd(), -1);
                break;
            case comparisonWithQoQQTD:
                start = IntervalDateUtils
                        .getDateBySeason(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateBySeason(currentDay.getEnd(), -1);
                break;
            case comparisonWithYoYYTD:
                start = IntervalDateUtils.getDateByYear(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateByYear(currentDay.getEnd(), -1);
                break;

            case comparisonWithYoYMTD:
                start = IntervalDateUtils.getDateByYear(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateByYear(currentDay.getEnd(), -1);
                break;
            case comparisonWithYoYQTD:
                start = IntervalDateUtils
                        .getDateBySeason(currentDay.getStart(), -1);
                end = IntervalDateUtils.getDateBySeason(currentDay.getEnd(), -1);
                break;
            case previous1D:
                start = IntervalDateUtils.getDateStart(-1, druidMaxDate);
                end = IntervalDateUtils.getDateStart(0, druidMaxDate);
                break;
            case previous7D:
                start = IntervalDateUtils.getDateStart(-7, druidMaxDate);
                end = IntervalDateUtils.getDateStart(0, druidMaxDate);
                break;
            case previous30D:
                start = IntervalDateUtils.getDateStart(-30, druidMaxDate);
                end = IntervalDateUtils.getDateStart(0, druidMaxDate);
                break;
            case comparisonWithP1D:
                start = IntervalDateUtils.getDateStart(-2, druidMaxDate);
                end = IntervalDateUtils.getDateStart(-1, druidMaxDate);
                break;
            case comparisonWithP7D:
                start = IntervalDateUtils.getDateStart(-14, druidMaxDate);
                end = IntervalDateUtils.getDateStart(-7, druidMaxDate);
                break;
            case comparisonWithP30D:
                start = IntervalDateUtils.getDateStart(-60, druidMaxDate);
                end = IntervalDateUtils.getDateStart(-30, druidMaxDate);
                break;
            case dynamicInterVal:
                String intervalType = contract.getHistoryInterval();
                Integer intervalNumber = contract.getIntervalNumber();
                start = DateUtils.getDateStartDynmaic(intervalNumber, intervalType);
                end = IntervalDateUtils.getDateByOffsetDynamic(currentDay.getEnd(), intervalNumber, intervalType);
        }

        // parser to UTC
        startTime4Clickhouse = IntervalDateUtils.getUTC(start,
                IntervalDateUtils.fmt_clickhouse);
        startTime4Druid = IntervalDateUtils.getUTC(start,
                IntervalDateUtils.fmt_druid);
        endTime4Clickhouse = IntervalDateUtils.getUTC(end,
                IntervalDateUtils.fmt_clickhouse);
        endTime4Druid = IntervalDateUtils.getUTC(end,
                IntervalDateUtils.fmt_druid);

        interval.setStart(start);
        interval.setEnd(end);
        interval.setStartTime4Clickhouse(startTime4Clickhouse);
        interval.setEndTime4Clickhouse(endTime4Clickhouse);
        interval.setStartTime4Druid(startTime4Druid);
        interval.setEndTime4Druid(endTime4Druid);
        interval.setInterval4Druid(startTime4Druid + "/" + endTime4Druid);
        return interval;
    }

}
