package com.newegg.bi.utils.query.interval;

public class IntervalContract {
	public IntervalContract(IntervalType intervalType) {
		super();
		this.intervalType = intervalType;
	}
	public IntervalContract(IntervalType intervalType,String historyInterval,Integer intervalNumber) {
		super();
		this.intervalType = intervalType;
		this.historyInterval =historyInterval;
		this.intervalNumber =intervalNumber;
	}


	private IntervalType intervalType;
	private String historyInterval;
	private Integer intervalNumber;

	public IntervalType getIntervalType() {
		return intervalType;
	}

	public String getHistoryInterval() {
		return historyInterval;
	}
	public void setHistoryInterval(String historyInterval) {
		this.historyInterval = historyInterval;
	}
	public Integer getIntervalNumber() {
		return intervalNumber;
	}
	public void setIntervalNumber(Integer intervalNumber) {
		this.intervalNumber = intervalNumber;
	}
	public void setIntervalType(IntervalType intervalType) {
		this.intervalType = intervalType;
	}

}
