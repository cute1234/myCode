package com.newegg.bi.utils.log;


public class LogApp {
	public static String BUYBOX_CUNSUMER = "BUYBOX_CUNSUMER";
	public static String BEHAVIOR_SIMULATOR = "BEHAVIOR_SIMULATOR";
	
	public static String META_REST = "META_REST";

	public static String RECEVIERS = "RECEVIERS";

}

