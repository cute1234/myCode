package com.newegg.bi.utils.db.entity;

public enum SqlFormatTypeEnum {
	SQL_FORMAT_TYPE_NON("   "),
	SQL_FORMAT_TYPE_JSON("  FORMAT JSON "),
	SQL_FORMAT_TYPE_XML(" FORMAT XML ");
	
	SqlFormatTypeEnum(String value){
		this.value=value;
	}
	
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
