package com.newegg.bi.utils.common;

import java.math.BigDecimal;

public enum DefaultEnum {
	VALUE_CORRECT_STRING("correct"),
	VALUE_ALL("all"),
	DEFAULT_DATE_FORMAT_YYYYMMDD("yyyy-MM-dd"),
	DEFAULT_DATE_FORMAT_YYYYMMDDHH("yyyy-MM-dd HH"),	
	DEFAULT_DATE_FORMAT_YYYYMMDDHHMMSSSSS("yyyy-MM-dd HH:mm:ss.SSS"),
	//DateUtils 會用到
	DATE("date"),
	MONTH("month"),
	WEEK("week"),
	QUARTER("quarter"),
	YEAR("year"),
	HOUR("hour"),
	MINUTE("minute");
	
	DefaultEnum(Object value){
		this.value = value ;
	}
	private Object value;

	public String getStringValue() {
		return String.valueOf(value);
	}
	public BigDecimal getBigDecimalValue() {
		return (BigDecimal) this.value ;
	}
}