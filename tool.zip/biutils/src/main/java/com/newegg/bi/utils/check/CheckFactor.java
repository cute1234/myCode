package com.newegg.bi.utils.check;

abstract class CheckFactor implements Factor{
	public abstract boolean check();
	
}