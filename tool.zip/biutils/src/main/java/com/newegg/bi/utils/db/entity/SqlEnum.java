package com.newegg.bi.utils.db.entity;

public enum SqlEnum {
	SQL_PARENTHESES_S(" ( "),
	SQL_PARENTHESES_E(" ) "),
	SQL_COMMA(" , "),
	SQL_AS(" AS "),
	SQL_SPACE(" "),
	SQL_OR(" OR "),
	SQL_AND(" AND "),
	SQL_APOSTROPHE("'"),
	SQL_EQUAL(" = "),	
	SQL_NOT_EQUAL(" <> "),
	SQL_GREATER_OR_EQUAL(" >= "),
	SQL_GREATER(" >"),
	SQL_LESS_OR_EQUAL(" <= "),
	SQL_LESS(" < "),
	
	SQL_SELECT(" SELECT "),
	SQL_FROM(" FROM "),
	SQL_WHERE(" WHERE "),
	
	SQL_GROUP_BY(" GROUP BY "),
	SQL_ORDER_BY(" ORDER BY "),
	
	SQL_FORMAT_TYPE_JSON("  FORMAT JSON "),
	SQL_FORMAT_TYPE_XML(" FORMAT XML ");
	
	SqlEnum(String value){
		this.value=value;
	}
	
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
