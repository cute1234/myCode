package com.newegg.bi.utils.item.itemcheck;

import java.util.regex.Pattern;

import com.newegg.bi.utils.item.AbstractItemCheck;
import com.newegg.bi.utils.item.ItemCheckEnum;

public class DSPrefixItemNumber extends AbstractItemCheck{

	@Override
	protected void setItemCheckEnum(ItemCheckEnum itemEnum) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected boolean proc(String itemNumber) {
		this.itemEnum=ItemCheckEnum.DSPrefix;
		String pattern=ItemCheckEnum.DSPrefix.getItemRole();
		boolean isMatch = Pattern.matches(pattern, itemNumber);
		return isMatch;
	}

}
