package com.newegg.bi.utils.log;

public class LogType {
	//BUYBOX_CUNSUMER
	public static String BUYBOX_ISSUE = "BUYBOX_ISSUE";
	public static String PRICE_GRABBER = "PRICE_GRABBER";
	public static String EC_RANKING = "EC_RANKING";
	
	//BEHAVIOR_SIMULATOR
	public static String CUSTOMER_PROFILE = "CUSTOMER_PROFILE";
	
	//META_REST
	public static String JSON_QUERY = "JSON_QUERY";
	public static String DOWNLOAD_CSV = "DOWNLOAD_CSV";
	public static String DOWNLOAD_LOG = "DOWNLOAD_LOG";

	//RECEVIERS
	public static String HBASE_GET_EIMS = "HBASE_GET_EIMS";
}
