package com.newegg.bi.utils.validator;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class FieldMatchValidator implements ConstraintValidator<FieldMatch, Object> {
	private String firstFieldName;
	private String secondFieldName;
	private String assertTypeName;
	private Object getReturnMethod(Object value,String getName) {
		String checkName ="get"+getName;
		for (Method f : value.getClass().getDeclaredMethods()) {			
			if (f.getName().toUpperCase().equals(checkName.toUpperCase())) {
				try {
					return f.invoke(value);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	@Override
	public void initialize(final FieldMatch constraintAnnotation) {
		firstFieldName = constraintAnnotation.first();
		secondFieldName = constraintAnnotation.second();
		assertTypeName = constraintAnnotation.assertType();
		if (null == assertTypeName || "".equals(assertTypeName)) {
			assertTypeName = "eq";
		}
	}
	private ConstraintValidatorContext setContextMessage(ConstraintValidatorContext context,String message) {
		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
		return context;
	}
	
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		try {
			if (null != value) {
				final Object firstObj = getReturnMethod(value,firstFieldName);
				final Object secondObj = getReturnMethod(value,secondFieldName);
				String assertWord = assertTypeName.toString();
				if (assertWord.equals("eq")) {
					if (firstObj != secondObj || !firstObj.toString().equals(secondObj.toString())) {
						setContextMessage(context,firstFieldName +"'s value should equal to "+secondFieldName);						
						return false;
					}
				}
				if (assertWord.equals("gte")) {
					if (firstObj.toString().compareTo(secondObj.toString()) < 0) {
						setContextMessage(context,firstFieldName +"'s value should greater than or equal to  "+secondFieldName);
						return false;
					}
				}
				if (assertWord.equals("lse")) {
					if (firstObj.toString().compareTo(secondObj.toString()) > 0) {
						setContextMessage(context,firstFieldName +"'s value should less than or equal to  "+secondFieldName);
						return false;
					}
				}
				if (assertWord.equals("gt")) {
					if (firstObj.toString().compareTo(secondObj.toString()) <= 0) {
						setContextMessage(context,firstFieldName +"'s value should greater than  "+secondFieldName);
						return false;
					}
				}
				if (assertWord.equals("ls")) {
					if (firstObj.toString().compareTo(secondObj.toString()) >= 0) {
						setContextMessage(context,firstFieldName +"'s value should less than  "+secondFieldName);
						return false;
					}
				}
				return true;
			}
		} catch (final Exception ignore) {
			ignore.printStackTrace();
		}
		return true;
	}

}
