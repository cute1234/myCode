package com.newegg.bi.utils.logx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

public class LogXlogEntity {
    @JsonProperty("LogType")
    private String logType;

    @JsonProperty("SeverityLevel")
    private String severityLevel;

    @JsonProperty("LogTimeStamp")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long logTimeStamp;

    public LogXlogEntity() {
    }

    public String getLogType() {
        return this.logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getSeverityLevel() {
        return this.severityLevel;
    }

    public void setSeverityLevel(String severityLevel) {
        this.severityLevel = severityLevel;
    }

    public Long getLogTimeStamp() {
        return this.logTimeStamp;
    }

    public void setLogTimeStamp(Long logTimeStamp) {
        this.logTimeStamp = logTimeStamp;
    }

    public String toString() {
        return "LogXlogEntity{logType='" + this.logType + '\'' + ", severityLevel='" + this.severityLevel + '\'' + ", logTimeStamp=" + this.logTimeStamp + '}';
    }
}
