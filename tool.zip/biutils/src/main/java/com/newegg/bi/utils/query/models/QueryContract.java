package com.newegg.bi.utils.query.models;

import java.util.List;

import com.newegg.bi.utils.query.interval.IntervalContract;
import com.newegg.bi.utils.query.models.FilterFieldsAggr;

public class QueryContract {
	private String dataSource;
	private FilterFieldsAggr filter;
	private IntervalContract intervalCurrent;
	private List<IntervalContract> intervalComparison;
	private ClickhouseScript clickhouseScript;
	private SqlScript sqlScript;
	private String timeBoundaryDataSourceFromClickhouse;

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public FilterFieldsAggr getFilter() {
		return filter;
	}

	public void setFilter(FilterFieldsAggr filter) {
		this.filter = filter;
	}

	public IntervalContract getIntervalCurrent() {
		return intervalCurrent;
	}

	public void setIntervalCurrent(IntervalContract intervalCurrent) {
		this.intervalCurrent = intervalCurrent;
	}

	public List<IntervalContract> getIntervalComparison() {
		return intervalComparison;
	}

	public void setIntervalComparison(List<IntervalContract> intervalComparison) {
		this.intervalComparison = intervalComparison;
	}

	public ClickhouseScript getClickhouseScript() {
		return clickhouseScript;
	}

	public void setClickhouseScript(ClickhouseScript clickhouseScript) {
		this.clickhouseScript = clickhouseScript;
	}

	public SqlScript getSqlScript() {
		return sqlScript;
	}

	public void setSqlScript(SqlScript sqlScript) {
		this.sqlScript = sqlScript;
	}

	public String getTimeBoundaryDataSourceFromClickhouse() {
		return timeBoundaryDataSourceFromClickhouse;
	}

	public void setTimeBoundaryDataSourceFromClickhouse(String timeBoundaryDataSourceFromClickhouse) {
		this.timeBoundaryDataSourceFromClickhouse = timeBoundaryDataSourceFromClickhouse;
	}

}
