package com.newegg.bi.utils.query.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class PostDruidAggr {
	private String queryType;
	private String dataSource;
	private Object granularity;
	private FilterFieldsAggr filter;	
	private List<ValueFieldsAggr> aggregations;
	private List<ValueFieldsAggr> postAggregations;
	private List<String> intervals;
	private List<DimensionFieldsAggr> dimensions;
	private DimensionFieldsAggr dimension;
	private Integer threshold;
	private ValueFieldsAggr metric;
	
	public String getQueryType() {
		return queryType;
	}
	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public Object getGranularity() {
		return granularity;
	}
//	public void setGranularity(Object granularity) {
//		this.granularity = granularity;
//	}
	public FilterFieldsAggr getFilter() {
		return filter;
	}
	public void setFilter(FilterFieldsAggr filter) {
		this.filter = filter;
	}
	public List<ValueFieldsAggr> getAggregations() {
		return aggregations;
	}
	public void setAggregations(List<ValueFieldsAggr> aggregations) {
		this.aggregations = aggregations;
	}
	public List<String> getIntervals() {
		return intervals;
	}
	public void setIntervals(List<String> intervals) {
		this.intervals = intervals;
	}
	
	public List<DimensionFieldsAggr> getDimensions() {
		return dimensions;
	}
	public void setDimensions(List<DimensionFieldsAggr> dimensions) {
		this.dimensions = dimensions;
	}
	
	
	public void setFilter(Map<String,String> queryMap) {
		FilterFieldsAggr filter = new FilterFieldsAggr();
		filter.setType("and");
		List<Object> fields = new ArrayList<>();
		for(String key:queryMap.keySet()){
			QueryFieldsAggr query = new QueryFieldsAggr();
			query.setType("selector");
			query.setDimension(key);
			query.setValue(queryMap.get(key));
			fields.add(query);
			filter.setFields(fields);
			setFilter(filter);
		}
	}
	
	public void setAggregations(Map<String,String> map) {
		List<ValueFieldsAggr> aggregations = new ArrayList<ValueFieldsAggr>();
		for(String key:map.keySet()){
			ValueFieldsAggr aggregation = new ValueFieldsAggr();
			aggregation.setType(map.get(key));
			aggregation.setName(key);
			aggregation.setFieldName(key);
			aggregations.add(aggregation);
			setAggregations(aggregations);
		}
	}
	
	
	public void setAggregationsAll_page_view() {
		List<ValueFieldsAggr> vList = new ArrayList<ValueFieldsAggr>();
		ValueFieldsAggr vAggr = new ValueFieldsAggr();
		vAggr.setFieldName("uniqueVisitors");
		vAggr.setName("Unique Visitors");
		vAggr.setType("hyperUnique");
		vList.add(vAggr);
		
		vAggr = new ValueFieldsAggr();
		vAggr.setFieldName("visits");
		vAggr.setName("Visits");
		vAggr.setType("hyperUnique");
		vList.add(vAggr);
		
		vAggr = new ValueFieldsAggr();
		vAggr.setFieldName("pageViews");
		vAggr.setName("Page Views");
		vAggr.setType("doubleSum");
		vList.add(vAggr);
		setAggregations(vList);
	}
	
	//2019.8.12 dara
	public void setGranularity(String granularity) {
		if (granularity.equals("all")) {
			this.granularity = granularity;
			return;
		}

		QranularityFieldsAggr aggr = new QranularityFieldsAggr();
		aggr.setType("period");
		aggr.setTimeZone("America/Los_Angeles");

		switch (granularity) {
			case "minute":
				aggr.setPeriod("PT1M");
				break;
			case "hour":
				aggr.setPeriod("PT1H");
				break;
			case "day":
				aggr.setPeriod("P1D");
				break;
			case "month":
				aggr.setPeriod("P1M");
				break;
			case "season":
				aggr.setPeriod("P3M");
				break;
			case "year":
				aggr.setPeriod("P1Y");
				break;
		}
		this.granularity = aggr;
	}
	public List<ValueFieldsAggr> getPostAggregations() {
		return postAggregations;
	}
	public void setPostAggregations(List<ValueFieldsAggr> postAggregations) {
		this.postAggregations = postAggregations;
	}
	public DimensionFieldsAggr getDimension() {
		return dimension;
	}
	public void setDimension(DimensionFieldsAggr dimension) {
		this.dimension = dimension;
	}
	public int getThreshold() {
		return threshold;
	}
	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}
	public ValueFieldsAggr getMetric() {
		return metric;
	}
	public void setMetric(ValueFieldsAggr metric) {
		this.metric = metric;
	}
}

	
