package com.newegg.bi.utils.db.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author bl5s
 *
 */
public class WhereStatement {
	private String linkType;
	private List<WhereEntity> list;
	private List<WhereStatement> listWhereStatement;
	
	public WhereStatement() {
		this.linkType=SqlEnum.SQL_AND.getValue();
		list=new ArrayList<WhereEntity>();
		listWhereStatement=new ArrayList<WhereStatement>();
	}
	public WhereStatement(String linkType) {
		this.linkType=linkType;
		list=new ArrayList<WhereEntity>();
		listWhereStatement=new ArrayList<WhereStatement>();
	}
	public void addWhere(WhereEntity entity) {
		list.add(entity);
	}
	
	public void addWhere(WhereStatement subWhereStatement) {
		listWhereStatement.add(subWhereStatement);
	}
	
	public void addWhere(String field,String value) {
		addWhere(field, value, SqlEnum.SQL_EQUAL.getValue(), true);
	}
	public void addWhere(String field,String value,String conditionType) {		
		addWhere(field, value, conditionType, true);
	}
	public void addWhere(String field,String value,String conditionType,boolean addApostrophe) {
		list.add(new WhereEntity(field, value,conditionType,addApostrophe));
	}
	
	
	
	
	public String toStatement(Boolean allowNonWhereStatement) {
		StringBuffer sb=new StringBuffer();
		
		//不允許沒where語句，但是又只有new 物件，有set 但是裡面沒東西
		if (!allowNonWhereStatement && null==list && list.size()==0 
				&& null==listWhereStatement && listWhereStatement.size()==0) {
			sb.append(" 1 ").append(SqlEnum.SQL_EQUAL).append(" 2 ");
			return sb.toString();
		}
		
		//有任何一個非空
		if (null!=list && list.size()>0) {
			sb.append(SqlEnum.SQL_PARENTHESES_S.getValue());
			for (int i = 0; i < list.size(); i++) {
				WhereEntity se=list.get(i);
				if (i!=0) {
					sb.append(linkType).append(SqlEnum.SQL_SPACE.getValue());
				}
				sb.append(se.getField()).append(se.getConditionType());
				if (se.isAddApostrophe()) {
					sb.append(SqlEnum.SQL_APOSTROPHE.getValue());
				}
				sb.append(se.getValue());
				if (se.isAddApostrophe()) {
					sb.append(SqlEnum.SQL_APOSTROPHE.getValue());
				}
			}
			sb.append(SqlEnum.SQL_PARENTHESES_E.getValue());
		}
		if (null!=listWhereStatement && listWhereStatement.size()>0) {
			if (null!=list && list.size()>0) {
				sb.append(linkType).append(SqlEnum.SQL_SPACE.getValue());
			}			
			for (int i = 0; i < listWhereStatement.size(); i++) {
				WhereStatement se=listWhereStatement.get(i);
				if (i!=0) {
					sb.append(linkType).append(SqlEnum.SQL_SPACE.getValue());
				}
				sb.append(se.toStatement(allowNonWhereStatement));
			}			
		}
		
		
		
		return sb.toString();
	}
}
