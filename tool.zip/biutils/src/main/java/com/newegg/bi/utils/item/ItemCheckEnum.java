package com.newegg.bi.utils.item;

/**
 * https://confluence.newegg.org/pages/viewpage.action?pageId=5542410
 * @author bl5s
 *
 */
public enum ItemCheckEnum {
	Seller("^9SI[0-9A-Z]{8,12}$"),
	Newegg("^[0-9A-Z]{2}[-][0-9A-Z]{3}[-][0-9A-Z]{3}$"),
	NeweggPrefix("^N82E168[0-9A-Z-]{8,12}$"),
	Parent("^[0-8][0-9A-Z]{2}[-][0-9A-Z]{4}[-][0-9A-Z]{4}[0-9]$"),
	AutoParts("^9AT[0-9A-Z]{8,12}$"),
	Book("^978[0-9]{10}$"),
	Used("^9U[A-D]{1}([0-9A-Z]{8}|[0-9A-Z]{2}[-][0-9A-Z]{3}[-][0-9A-Z]{3})$"),
	OpenBox("(^N82E168[0-9A-Z-]{8,12}|^[0-9A-Z-]{10,14})(R|D)$"),
	CVFPostfix("[0-9A-Z-]{8,14}CVF$"),
	SFPostfix("[0-9A-Z-]{7,12}SF$"),
	DSPrefix("^DS[-][0-9A-Z]{4,12}"),
	INPostfix("[0-9A-Z-]{7,12}IN$"),
	TSPostfix("	[0-9A-Z-]{7,12}TS$"),
	SNETPrefix("^SNET[-][0-9]{6}$"),
	EWRAPrefix("^EWRA[-][0-9]{3}$"),
	DVD("(^N82E168[0-9]{12}|^[0-9]{12,14})$"),
	B2BPrefix("^9B[0-9A-Z-]{8,23}$"),
	GiftWrap("^BOX[-][0-9A-Z]{3}$");
	ItemCheckEnum(String role){
		setItemRole(role);
	};
	private String itemRole;
	public String getItemRole() {
		return itemRole;
	}
	public void setItemRole(String itemRole) {
		this.itemRole = itemRole;
	}	
}
