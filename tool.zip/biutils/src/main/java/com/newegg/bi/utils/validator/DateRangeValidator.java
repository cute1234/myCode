package com.newegg.bi.utils.validator;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.newegg.bi.utils.common.DateUtils;

public class DateRangeValidator implements ConstraintValidator<DateRange, Object> {
	private String firstFieldName;
	private String secondFieldName;
	private String greatThenToday;
	private String dateRangeValue;
	@Override
	public void initialize(final DateRange constraintAnnotation) {
		firstFieldName = constraintAnnotation.first();
		secondFieldName = constraintAnnotation.second();
		greatThenToday = constraintAnnotation.greatThenToday();
		dateRangeValue= constraintAnnotation.dateRange();
		if (null == greatThenToday || "".equals(greatThenToday)) {
			greatThenToday = "f";
		}
	}

	private Object getReturnMethod(Object value,String getName) {
		String checkName ="get"+getName;
		for (Method f : value.getClass().getDeclaredMethods()) {			
			if (f.getName().toUpperCase().equals(checkName.toUpperCase())) {
				try {
					return f.invoke(value);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		try {
			if (null != value) {
				final Object firstObj = getReturnMethod(value,firstFieldName);
				final Object secondObj = getReturnMethod(value,secondFieldName);
				int dateRange= Integer.valueOf(dateRangeValue.toString());
				String assertWord = greatThenToday.toString();
				if (assertWord.equals("f")) {
					if (DateUtils.getDateTime("yyyy-MM-dd").compareTo(firstObj.toString())<0) {
						setContextMessage(context,firstFieldName +"'s value should less than or equal to  "+DateUtils.getDateTime("yyyy-MM-dd"));
						return false;
					}
					if (DateUtils.getDateTime("yyyy-MM-dd").compareTo(secondObj.toString())<0) {
						setContextMessage(context,secondFieldName +"'s value should less than or equal to  "+DateUtils.getDateTime("yyyy-MM-dd"));
						return false;
					}
				}
				if(addDay(firstObj.toString(), dateRange).compareTo(secondObj.toString())<0){					
					return false;
				}
				return true;
			}
		} catch (final Exception ignore) {
			ignore.printStackTrace();
		}
		return true;
	}
	private  String addDay(String dateString, int num) {		
		Calendar startDT = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date;
		String returnString=dateString;
		try {
			date = sdf.parse(dateString);
			startDT.setTime(date);
			startDT.add(Calendar.DATE, num);
			returnString=sdf.format(startDT.getTime()).trim();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return returnString;
	}
	private ConstraintValidatorContext setContextMessage(ConstraintValidatorContext context,String message) {
		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
		return context;
	}
}
