package com.newegg.bi.utils.query.models;


public class SqlScript extends ClickhouseScript {

}
