package com.newegg.bi.utils.db.entity;

public class WhereEntity {
	private String field;
	private String value;
	private String conditionType;
	private boolean addApostrophe;
	
	public WhereEntity(String field,String value) {
		setField(field);
		setValue(value);
		setConditionType(SqlEnum.SQL_EQUAL.getValue());
		setAddApostrophe(true);
	}
	public WhereEntity(String field,String value,String conditionType) {
		setField(field);
		setValue(value);
		setConditionType(conditionType);
		setAddApostrophe(true);
	}
	public WhereEntity(String field,String value,String conditionType,boolean addApostrophe) {
		setField(field);
		setValue(value);
		setConditionType(conditionType);
		setAddApostrophe(addApostrophe);
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getConditionType() {
		return conditionType;
	}
	public void setConditionType(String conditionType) {
		this.conditionType = conditionType;
	}
	public boolean isAddApostrophe() {
		return addApostrophe;
	}
	public void setAddApostrophe(boolean addApostrophe) {
		this.addApostrophe = addApostrophe;
	}
	
	
}
