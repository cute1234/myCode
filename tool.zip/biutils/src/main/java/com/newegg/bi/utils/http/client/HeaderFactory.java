package com.newegg.bi.utils.http.client;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

public class HeaderFactory {
	private static final String headerNameSID = "x-gateway-sid";
	private static final String headerNameTID = "x-gateway-tid";
	private static final String headerServiceName = "ServiceName";
	public static final String BIServiceNameRealtimeREST = "BI.RealtimeREST";
	public static final String BIServiceNameReceiversSO = "BI.ReceiversSO";
	public static final String BIServiceNameReceiversPersist = "BI.ReceiversPersist";
	public static final String BIServiceNameCustomerBehavior = "BI.CustomerBehavior";
	public static final String BIServiceNameBuybox = "BI.Buybox";
	public static final String BIServiceNameSORealtimeQuery = "BI.SORealtimeQuery";


	public static MultivaluedMap<String, Object> build(HttpServletRequest webRequest, String serviceName) {
		MultivaluedMap<String, Object> header_default = new MultivaluedHashMap<>();
		header_default.add("Accept", "application/json");
		if (webRequest != null) {
			header_default.add(headerNameSID, webRequest.getHeader(headerNameSID));
			header_default.add(headerNameTID, webRequest.getHeader(headerNameTID));
		}
		if (serviceName != null) {
			header_default.add(headerServiceName, serviceName);
		}

		return header_default;
	}

	@Deprecated
	public static MultivaluedMap<String, Object> build(HttpServletRequest webRequest) {
		return build(webRequest, BIServiceNameRealtimeREST);
	}
}
