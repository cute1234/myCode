package com.newegg.bi.utils.query.models;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;


public class DruidRequestContainer {
	
	private List<QueryFieldsAggr> dimensions; //Fields
	private List<ValueFieldsAggr> measures; //Aggregations
	private String time;
	private String compare;
	
	public List<QueryFieldsAggr> getDimensions() {
		return dimensions;
	}
	public void setDimensions(List<QueryFieldsAggr> dimensions) {
		this.dimensions = dimensions;
	}
	public List<ValueFieldsAggr> getMeasures() {
		return measures;
	}
	public void setMeasures(List<ValueFieldsAggr> measures) {
		this.measures = measures;
	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getCompare() {
		return compare;
	}
	public void setCompare(String compare) {
		this.compare = compare;
	}

	public static void main(String[] args){
		DruidRequestContainer request=new DruidRequestContainer();
		List<QueryFieldsAggr> dimensions = new ArrayList<QueryFieldsAggr>();
		QueryFieldsAggr dimension = new QueryFieldsAggr();
		dimension.setType("selector");
		dimension.setDimension("Chrome Pagename");;
		dimension.setValue("home:productlist");
		dimensions.add(dimension);
		
		dimension = new QueryFieldsAggr();
		dimension.setType("selector");
		dimension.setDimension("Chrome Channel");;
		dimension.setValue("daily deals");
		dimensions.add(dimension);
		request.setDimensions(dimensions);
		
		List<ValueFieldsAggr> measures = new ArrayList<ValueFieldsAggr>();
		ValueFieldsAggr measure = new ValueFieldsAggr();
		measure.setType("doubleSum");
		measure.setName("Page Views");
		measure.setFieldName("Page Views");
		measures.add(measure);
		request.setMeasures(measures);
		
		request.setTime("Latest 1 Hour");
		request.setCompare("1 Weeks Prior");
		
		System.out.println(new Gson().toJson(request));
	}
	
	
}

	
