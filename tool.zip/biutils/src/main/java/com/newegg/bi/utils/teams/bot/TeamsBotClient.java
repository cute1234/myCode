package com.newegg.bi.utils.teams.bot;

import com.newegg.bi.utils.teams.bot.models.RequestMessage;

public class TeamsBotClient {
	private static String ADMIN_MAILS_DEV = "Wilson.W.Tu@newegg.com;";
	private static String ADMIN_MAILS = "Wilson.W.Tu@newegg.com;Jaden.C.Cheng;Sam.C.Pai;";
	public RequestMessage requestMessageFactory(String title) {
		RequestMessage message = new RequestMessage();
		message.setCardType("ADAPTIVE");
		message.setUuid("1611639001751");
		
		
		
		return message;
	}
}
