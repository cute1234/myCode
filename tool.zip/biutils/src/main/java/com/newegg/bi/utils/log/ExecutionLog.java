package com.newegg.bi.utils.log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.newegg.bi.utils.common.DateUtils;
import com.newegg.bi.utils.common.StringUtils;

public class ExecutionLog {

	private Logger logger = Logger.getLogger(ExecutionLog.class);
	private String logHome;
	private PrintWriter writer;
	private NumberFormat fmt = new DecimalFormat("#0.00000");
	private int TTL = 7;

	public void init(String logHome) {
		this.logHome = logHome;
	}

	private String getFilePath(String app, Date date) {
		return logHome + "/" + app + DateUtils.toDateStrYYYYMMDD(date) + ".json";
	}

	private synchronized void saveToFile(LogEntity containerLog, String app) {
		File file = new File(getFilePath(app, new Date()));
		try {
			if (!file.exists()) {
				logger.info("createNewFile:" + file);
				file.createNewFile();
				removeHistoryFile(app);
			}
			writer = new PrintWriter(new FileOutputStream(file, true));
			String result = StringUtils.toGson(containerLog) + "\r\n";
			writer.write(result);
			writer.flush();
			writer.close();
		} catch (IOException e) {
			logger.error("save file error:" + e.getMessage());
			e.printStackTrace();
		}
	}

	private void removeHistoryFile(String app) {
		File file = new File(getFilePath(app, DateUtils.getDateStart(-TTL)));
		logger.info("filePath_old:" + file);
		if (file.exists()) {
			if (file.delete()) {
				logger.info("old file is deleted:" + file);
			} else {
				logger.error("old file is failed:" + file);
			}
		}
	}

	public List<LogEntity> readLogFile(String app) throws IOException {
		return readLogFile(app, new Date());
	}

	public List<LogEntity> readLogFile(String app, Date date) throws IOException {
		List<LogEntity> logList = new ArrayList<>();
		File file = new File(getFilePath(app, date));
		logger.info("filePath:" + file);

		BufferedReader reader = new BufferedReader(new FileReader(file.getAbsolutePath()));
		String line;
		LogEntity containerLog;
		while ((line = reader.readLine()) != null) {
			containerLog = StringUtils.fromGson(line, LogEntity.class);
			logList.add(containerLog);
		}
		reader.close();
		return logList;
	}

	public void saveLog(long startTime, LogEntity log) {
		log.setLogDate(DateUtils.getDateTime(new Date(), "yyyy-MM-dd HH:mm:ss"));
		log.setExecutionTime(executionTime(startTime));
		saveToFile(log, log.getLogApp());
	}

	public long saveLog(long startTime, String logApp, String logType, String logContent, boolean isSuccess) {
		LogEntity log = new LogEntity();
		log.setIsSuccess(isSuccess);
		log.setLogApp(logApp);
		log.setLogType(logType);
		log.setLogDate(DateUtils.getDateTime(new Date(), "yyyy-MM-dd HH:mm:ss"));
		log.setExecutionTime(executionTime(startTime));
		log.setLogContent(logContent);
		saveToFile(log, log.getLogApp());
		return System.currentTimeMillis();
	}

	public long saveLog(long startTime, String logApp, String logType, String logContent, boolean isSuccess, Double delayLimit) {
		LogEntity log = new LogEntity();
		log.setIsSuccess(isSuccess);
		log.setLogApp(logApp);
		log.setLogType(logType);
		log.setLogDate(DateUtils.getDateTime(new Date(), "yyyy-MM-dd HH:mm:ss"));
		log.setExecutionTime(executionTime(startTime));
		log.setLogContent(logContent);
		if (Double.valueOf(log.getExecutionTime()) > delayLimit) {
			log.setMemo("delay");
		}
		saveToFile(log, log.getLogApp());
		return System.currentTimeMillis();
	}

	public long saveLog(long startTime, String logApp, String logType, String logContent, boolean isSuccess, String userID) {
		LogEntity log = new LogEntity();
		log.setIsSuccess(isSuccess);
		log.setLogApp(logApp);
		log.setLogType(logType);
		log.setLogDate(DateUtils.getDateTime(new Date(), "yyyy-MM-dd HH:mm:ss"));
		log.setExecutionTime(executionTime(startTime));
		log.setLogContent(logContent);
		log.setUserID(userID);
		saveToFile(log, log.getLogApp());
		return System.currentTimeMillis();
	}

	public long saveLog(String executionTim, String logApp, String logType, String logContent, boolean isSuccess) {
		LogEntity log = new LogEntity();
		log.setIsSuccess(isSuccess);
		log.setLogApp(logApp);
		log.setLogType(logType);
		log.setLogDate(DateUtils.getDateTime(new Date(), "yyyy-MM-dd HH:mm:ss"));
		log.setExecutionTime(executionTim);
		log.setLogContent(logContent);
		saveToFile(log, log.getLogApp());
		return System.currentTimeMillis();
	}

	public String executionTime(long start) {
		return fmt.format((System.currentTimeMillis() - start) / 1000d);
	}

	public void printWriterLog(Exception e, Logger logger) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		logger.error(sw.toString());
	}

	public int getTTL() {
		return TTL;
	}

	public void setTTL(int tTL) {
		TTL = tTL;
	}
}
