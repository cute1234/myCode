package com.newegg.bi.utils.mail;

import java.util.List;

public class EmailEntity {
	private String systemID;
	private String countryCode;
	private Integer companyCode;
	private String languageCode;
	private Integer customerNumber;
	private String toName;
	private String ccName;
	private String bccName;
	private String fromName;
	private String replyName;
	private String subject;
	private String body;
	private Integer priority;
	private Integer htmlType;
	private String templateID;

	private List<DataVariable> dataVariables;

	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Integer getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(Integer companyCode) {
		this.companyCode = companyCode;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public Integer getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(Integer customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getToName() {
		return toName;
	}

	public void setToName(String toName) {
		this.toName = toName;
	}

	public String getCcName() {
		return ccName;
	}

	public void setCcName(String ccName) {
		this.ccName = ccName;
	}

	public String getBccName() {
		return bccName;
	}

	public void setBccName(String bccName) {
		this.bccName = bccName;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getReplyName() {
		return replyName;
	}

	public void setReplyName(String replyName) {
		this.replyName = replyName;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Integer getHtmlType() {
		return htmlType;
	}

	public void setHtmlType(Integer htmlType) {
		this.htmlType = htmlType;
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public List<DataVariable> getDataVariables() {
		return dataVariables;
	}

	public void setDataVariables(List<DataVariable> dataVariables) {
		this.dataVariables = dataVariables;
	}

}
