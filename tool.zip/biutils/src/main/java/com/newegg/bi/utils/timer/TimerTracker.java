package com.newegg.bi.utils.timer;

import com.newegg.bi.utils.common.DateUtils;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * Created by Dara.L.Huang on 11/16/2018.
 * Email : Dara.L.Huang@newegg.com
 */
public class TimerTracker {

    private static Logger logger = Logger.getLogger(TimerTracker.class);
    private static Map<String,TimerPlan> timerMap = new HashMap<>();

    public void runCrossDay(int min, TimerTask timerTask) {
        timerMap.put(timerTask.getClass().getName(), new TimerPlan(DateUtils.getDateStart_min(min)));
        runCrossDay(timerTask);
    }

    public void runCrossDay(Date date, TimerTask timerTask) {
        timerMap.put(timerTask.getClass().getName(), new TimerPlan(date));
        runCrossDay(timerTask);
    }

    private static Date getDateStart(int hr, int min, int sec) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hr);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, sec);
        Date date = calendar.getTime();
        Date d = new Date();
        if (date.equals(d) || date.before(d)) {
            calendar.add(Calendar.DATE, 1); // add one day more
            date = calendar.getTime();
        }
        return date;
    }

    private static void runCrossDay(TimerTask timerTask) {
        TimerPlan timerPlan = timerMap.get(timerTask.getClass().getName());
        if (timerPlan == null) {
            logger.error("timer not found " + timerTask.getClass().getName());
            return;
        }
        timerPlan.getTimer().schedule(timerTask, getDateStart(timerPlan.getHr(), timerPlan.getMin(), timerPlan.getSec()));
    }

    public static void reSchedule(TimerTask timerTask) {
        runCrossDay(timerTask);
    }
}

