package com.newegg.bi.utils.monitor;

public class MonitorActiveEntity {
	private String mointorService;
	private String mointorType;
	private String mointorJob;
	private String activeStatus;
	private String modifyByIp;
	private String modifyTime;
	public String getMointorService() {
		return mointorService;
	}
	public void setMointorService(String mointorService) {
		this.mointorService = mointorService;
	}
	public String getMointorType() {
		return mointorType;
	}
	public void setMointorType(String mointorType) {
		this.mointorType = mointorType;
	}
	public String getMointorJob() {
		return mointorJob;
	}
	public void setMointorJob(String mointorJob) {
		this.mointorJob = mointorJob;
	}
	public String getActiveStatus() {
		return activeStatus;
	}
	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}
	public String getModifyByIp() {
		return modifyByIp;
	}
	public void setModifyByIp(String modifyByIp) {
		this.modifyByIp = modifyByIp;
	}
	public String getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(String modifyTime) {
		this.modifyTime = modifyTime;
	}
	

	
}
