package com.newegg.bi.utils.db.entity;

public class SqlTest {
	public static void main(String[] arg) {
		SqlTest ru=new SqlTest();
		ru.run();
	}
	public void run() {
		SqlBuilder bu=new SqlBuilder(true);
		SelectStatement ss=new SelectStatement();
		ss.addSelect("toMonth(timestamp)", "Month");
		ss.addSelect("toDayOfMonth(timestamp)", "Day");
		ss.addSelect("toHour(timestamp)", "Hour");
		ss.addSelect("sum(send)", "send");
		ss.addSelect("sum(open)", "open");
		ss.addSelect("sum(delivery)", "delivery");
		ss.addSelect("sum(impression)", "impression");
		//toMonth(timestamp),toDayOfMonth(timestamp),toHour(timestamp),sum(send),sum(open),sum(delivery),sum(impression)
		
		
		
		WhereStatement ws=new WhereStatement(SqlEnum.SQL_AND.getValue());
		ws.addWhere("timestamp", "2022-02-15 05:00:00",SqlEnum.SQL_GREATER_OR_EQUAL.getValue());
		ws.addWhere("timestamp", "2022-02-16 05:00:00",SqlEnum.SQL_LESS_OR_EQUAL.getValue());
		


		
		bu.setSelect(ss);
		From from=new From("s_email_performance");
		bu.setFrom(from);
		bu.setWhere(ws);
		GroupBy gb=new GroupBy();
		gb.addGroupBy("toMonth(timestamp)");
		gb.addGroupBy("toDayOfMonth(timestamp)");
		gb.addGroupBy("toHour(timestamp)");
		bu.setGroupBy(gb);
		OrderBy ob=new OrderBy();
		ob.addOrderBy("toMonth(timestamp)");//toMonth(timestamp),toDayOfMonth(timestamp),toHour(timestamp)
		ob.addOrderBy("toDayOfMonth(timestamp)");//toMonth(timestamp),toDayOfMonth(timestamp),toHour(timestamp)
		ob.addOrderBy("toHour(timestamp)");//toMonth(timestamp),toDayOfMonth(timestamp),toHour(timestamp)
		bu.setOrderBy(ob);
		String sql =bu.buildSqlStatement(SqlFormatTypeEnum.SQL_FORMAT_TYPE_JSON);
		

		System.out.println(sql);
	}
}
