package com.newegg.bi.utils.query.interval;

import java.util.Date;

public class Interval {
	private Date start;
	private Date end;
	private IntervalType intervalType;
	private String startTime4Clickhouse;
	private String endTime4Clickhouse;
	private String startTime4Druid;
	private String endTime4Druid;
	private String interval4Druid;

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}
	
	public String getStartTime4Clickhouse() {
		return startTime4Clickhouse;
	}

	public void setStartTime4Clickhouse(String startTime4Clickhouse) {
		this.startTime4Clickhouse = startTime4Clickhouse;
	}

	public String getEndTime4Clickhouse() {
		return endTime4Clickhouse;
	}

	public void setEndTime4Clickhouse(String endTime4Clickhouse) {
		this.endTime4Clickhouse = endTime4Clickhouse;
	}

	public String getStartTime4Druid() {
		return startTime4Druid;
	}

	public void setStartTime4Druid(String startTime4Druid) {
		this.startTime4Druid = startTime4Druid;
	}

	public String getEndTime4Druid() {
		return endTime4Druid;
	}

	public void setEndTime4Druid(String endTime4Druid) {
		this.endTime4Druid = endTime4Druid;
	}

	public String getInterval4Druid() {
		return interval4Druid;
	}

	public void setInterval4Druid(String interval4Druid) {
		this.interval4Druid = interval4Druid;
	}

	@Override
	public String toString() {
		return "Interval [startTime4Clickhouse=" + startTime4Clickhouse + ", endTime4Clickhouse=" + endTime4Clickhouse + ", startTime4Druid=" + startTime4Druid + ", endTime4Druid=" + endTime4Druid + ", interval4Druid=" + interval4Druid + "]";
	}

	public IntervalType getIntervalType() {
		return intervalType;
	}

	public void setIntervalType(IntervalType intervalType) {
		this.intervalType = intervalType;
	}

	

}
