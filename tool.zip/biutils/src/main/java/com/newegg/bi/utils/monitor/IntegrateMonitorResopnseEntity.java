package com.newegg.bi.utils.monitor;

import java.util.List;

public class IntegrateMonitorResopnseEntity {
	private boolean status;
	private String processDateTime;
	private List<String> reference;
	private Object response;
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getProcessDateTime() {
		return processDateTime;
	}
	public void setProcessDateTime(String processDateTime) {
		this.processDateTime = processDateTime;
	}
	public List<String> getReference() {
		return reference;
	}
	public void setReference(List<String> reference) {
		this.reference = reference;
	}
	public Object getResponse() {
		return response;
	}
	public void setResponse(Object response) {
		this.response = response;
	}


	
}
