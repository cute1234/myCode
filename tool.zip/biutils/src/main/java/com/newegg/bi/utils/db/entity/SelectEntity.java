package com.newegg.bi.utils.db.entity;

public class SelectEntity {
	private String alias;
	private String field;
	public SelectEntity(String field,String alias) {
		setAlias(alias);
		setField(field);
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	
}
