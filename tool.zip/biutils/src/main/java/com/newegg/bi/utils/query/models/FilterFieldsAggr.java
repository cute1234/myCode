package com.newegg.bi.utils.query.models;

import java.util.List;

public class FilterFieldsAggr {
	private String type;
	private List<Object> fields;
	private String clickhouse;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Object> getFields() {
		return fields;
	}

	public void setFields(List<Object> fields) {
		this.fields = fields;
	}

	public FilterFieldsAggr() {
	}

	public FilterFieldsAggr(String type, List<Object> fields) {
		this.type = type;
		this.fields = fields;
	}

	public String getClickhouse() {
		return clickhouse;
	}

	public void setClickhouse(String clickhouse) {
		this.clickhouse = clickhouse;
	}
}
