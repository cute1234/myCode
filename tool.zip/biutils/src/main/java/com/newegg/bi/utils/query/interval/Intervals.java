package com.newegg.bi.utils.query.interval;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class Intervals extends LinkedHashMap<IntervalType, Interval> {
	public List<String> getIntervalList() {
		List<String> r = new ArrayList<>();
		this.forEach((k,v)->{
			r.add(v.getInterval4Druid());
		});
		return r;
	}

}
