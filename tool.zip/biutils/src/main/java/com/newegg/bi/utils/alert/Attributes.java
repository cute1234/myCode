package com.newegg.bi.utils.alert;

public class Attributes {
    private String ownerEmail;
    private String ownerGroups;
    private String impactGroups;
    private String moreInfo;
    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    public String getOwnerGroups() {
        return ownerGroups;
    }

    public void setOwnerGroups(String ownerGroups) {
        this.ownerGroups = ownerGroups;
    }

    public String getImpactGroups() {
        return impactGroups;
    }

    public void setImpactGroups(String impactGroups) {
        this.impactGroups = impactGroups;
    }

	public String getMoreInfo() {
		return moreInfo;
	}

	public void setMoreInfo(String moreInfo) {
		this.moreInfo = moreInfo;
	}


}
