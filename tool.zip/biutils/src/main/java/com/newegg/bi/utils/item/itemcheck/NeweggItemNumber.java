package com.newegg.bi.utils.item.itemcheck;

import java.util.regex.Pattern;

import com.newegg.bi.utils.item.AbstractItemCheck;
import com.newegg.bi.utils.item.ItemCheckEnum;

public class NeweggItemNumber extends AbstractItemCheck{

	@Override
	protected void setItemCheckEnum(ItemCheckEnum itemEnum) {
		this.itemEnum=itemEnum;
	}

	@Override
	protected boolean proc(String itemNumber) {
		String pattern=ItemCheckEnum.Newegg.getItemRole();
		boolean isMatch = Pattern.matches(pattern, itemNumber);
		return isMatch;
	}

}
