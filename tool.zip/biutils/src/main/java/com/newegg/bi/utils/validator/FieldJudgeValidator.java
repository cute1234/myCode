package com.newegg.bi.utils.validator;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class FieldJudgeValidator implements ConstraintValidator<FieldJudge, Object> {
	public static final  int  JUDGE_TYPE_V1_NULL_V2_BE_NULL=1;
	public static final  int  JUDGE_TYPE_V1_NOT_NULL_V2_NOT_NULL=2;
	public static final  int  JUDGE_TYPE_V1_NOT_NULL_V2_SHOULD_BE_NULL=3;
	public static final  int  JUDGE_TYPE_V1_NOT_NULL_V2_SHOULD_BE_IN_ALLOW=4;	
	public static final  int  JUDGE_TYPE_V1_IN_SOME_VALUE_V2_SHOULD_BE_NULL=5;
	public static final  int  JUDGE_TYPE_V1_IN_SOME_VALUE_V2_SHOULD_BE_IN_ALLOW=6;
	
	private String firstFieldName;
	private String secondFieldName;
	private String allowValueName;
	private String judgeTypeName;
	private String firstSpecificValue;
	
	private Object getReturnMethod(Object value,String getName) {
		String checkName ="get"+getName;
		for (Method f : value.getClass().getDeclaredMethods()) {			
			if (f.getName().toUpperCase().equals(checkName.toUpperCase())) {
				try {
					return f.invoke(value);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	
	@Override
	public void initialize(final FieldJudge constraintAnnotation) {
		firstFieldName = constraintAnnotation.first();
		secondFieldName = constraintAnnotation.second();		
		judgeTypeName=constraintAnnotation.judgetype();
		allowValueName = constraintAnnotation.allowValue();
		firstSpecificValue=constraintAnnotation.firstSpecificValue();
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		try {
			if (null != value) {
				//BeanWrapper beanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(value);
				final Object firstObj = getReturnMethod(value,firstFieldName);
				final Object secondObj = getReturnMethod(value,secondFieldName);

				String allowValue = allowValueName.toString();
				int judgeType = Integer.valueOf(judgeTypeName.toString()); 
				String v1Value=firstObj.toString();
				String v2Value=secondObj.toString();
				if(JUDGE_TYPE_V1_NULL_V2_BE_NULL==judgeType) {
					//v1 空 or null  v2 必須為空 or null 	
					if (null==v1Value || "".equals(v1Value)) {
						if (null!=v2Value || !"".equals(v2Value)) {
							return false;
						}
					}
					
				}else if (JUDGE_TYPE_V1_NOT_NULL_V2_NOT_NULL==judgeType) {
					//v1 not 空 v2 必須有特定值
					if (null!=v1Value && !"".equals(v1Value)) {
						if (null ==v2Value || "".equals(v2Value)) {
							return false;
						}
					}					
					
				}else if (JUDGE_TYPE_V1_NOT_NULL_V2_SHOULD_BE_IN_ALLOW==judgeType) {
					//v1 not 空 v2 必須有值
					if (null!=v1Value && !"".equals(v1Value)) {
						String[] allowValueArray=allowValue.split(",");
						boolean findInAllow=false;
						if (null ==v2Value || "".equals(v2Value)) {
							return false;
						}
						if (null==allowValueArray ||allowValueArray.length==0) {
							return false;
						}else {
							for (int i = 0; i < allowValueArray.length; i++) {
								String allowValueString=allowValueArray[i];
								System.out.println(allowValueString);
								if (allowValueString.equals(v2Value)) {
									findInAllow=true;
									break;
								}
							}
						}
						if (!findInAllow) {
							return false;
						}
					}
					
					
				}else if (JUDGE_TYPE_V1_IN_SOME_VALUE_V2_SHOULD_BE_NULL==judgeType) {
					//v1 not 空 且為特定值 v2 必須為空
					
					
				}else if (JUDGE_TYPE_V1_IN_SOME_VALUE_V2_SHOULD_BE_IN_ALLOW==judgeType) {
					//v1 not 空 且為特定值 v2 必須為特定值
					
					return false;
				}else {
					
					return false;
				}
				return true;
			}
		} catch (final Exception ignore) {
			ignore.printStackTrace();
		}
		return true;
	}

}
