package com.newegg.bi.utils.db;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

public class ExportUtils {

    private String server;
    private String database;
    private String username;
    private String password;
    private String driver;
    private String url;
    
    private static Logger log = Logger.getLogger(ExportUtils.class);
   
   
    //old
    public ExportUtils(String _server, String _database, String _username,String _password){
        this.url="jdbc:jtds:sqlserver://"+_server+":1433/"+_database;
    	this.driver="net.sourceforge.jtds.jdbc.Driver";
        this.username=_username;
        this.password=_password;
        log.info("connect db:"+url);
    }
    
	public void executeUpdateSQl(String sql){
		//Connect to SQL Server
        Connection connMSSQL;
        try {
        	try {
				Class.forName(driver);
				//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
            connMSSQL = DriverManager.getConnection(url, username, password);
            Statement stmt = (Statement) connMSSQL.createStatement();
            stmt.executeUpdate(sql);
            //ResultSet res = stmt.executeQuery(sql);
            //ResultSetMetaData rsmd = res.getMetaData();
            //System.out.println("Retrieving data..."+String.valueOf(result));
            
            //res.close();
            //res=null;
            connMSSQL.close();
        } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        } finally {
                connMSSQL=null;
        } 
        // end sql
	}

	@SuppressWarnings("finally")
	public ResultSet executeSQl(String sql){
		//Connect to SQL Server
        Connection connMSSQL;
        try {
        	try {
				Class.forName(driver);
				//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
            connMSSQL = DriverManager.getConnection(url, username, password);
            Statement stmt = (Statement) connMSSQL.createStatement();
            //int result = stmt.executeUpdate(sql);
            ResultSet res = stmt.executeQuery(sql);
            //ResultSetMetaData rsmd = res.getMetaData();
            //System.out.println("Retrieving data..."+String.valueOf(result));
            
            //res.close();
            //res=null;
            connMSSQL.close();
            return res;
        } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return null;
        } finally {
                connMSSQL=null;
                return null;
        } 
        // end sql
	}
	
	public void executeCallSQl(String sql,HashMap<String,String> map,String keyName ,String valueName){
		//Connect to SQL Server
        Connection connMSSQL;
        try {
        	try {
				Class.forName(driver);
				//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
            connMSSQL = DriverManager.getConnection(url, username, password);
           /* CallableStatement cs = null;
            cs = connMSSQL.prepareCall("{"+sql+"}");
            ResultSet res = cs.executeQuery();*/
            
            PreparedStatement ps = connMSSQL.prepareStatement(sql);
            ps.setEscapeProcessing(true);
            ps.setQueryTimeout(5000);
            //ps.setString(1, <param1>);
            //ps.setString(2, <param2>);
            ResultSet res = ps.executeQuery();

            while(res.next()){
            	//map.put(res.getString("category"),res.getString("domain"));
            	if(res.getString(keyName)!=null)
            		map.put(res.getString(keyName).toLowerCase(),res.getString(valueName));
			}
            
            
            connMSSQL.close();
        } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        } finally {
                connMSSQL=null;
        } 
        // end sql
	}

	
	//通用, 以後用這個
	public <M> void createTablePOJO(String tablename,Class<M> mClass) {
		boolean first = true;
		StringBuilder sql =  new StringBuilder();
		sql.append("if not exists (select 1 from sysobjects where name='"+tablename+"' and xtype='U')");
		sql.append("CREATE TABLE [dbo].["+tablename+"](");
		//Method [] method = mClass.getDeclaredMethods() ;
		Method [] method = mClass.getMethods() ; //include all methods extending another
 
		for(int i = 0; i < method.length; i++){
			String methodName = method[i].getName();
			if(methodName.startsWith("get")){
	             //fields.put(method[i].getName().replace("get", ""), method[i].getReturnType().getName()); 
				if(!first){
					sql.append(",");
				}else{
					first = false;
				}
				if(method[i].getName().toLowerCase().contains("date")){
					log.info("method:"+method[i].getName());
					log.info("type:"+method[i].getReturnType().getName());
				}
				if(method[i].getReturnType().getName().equals("java.util.Date")){
					sql.append("["+method[i].getName().replace("get", "")+"] [datetime]");
				}else{
					sql.append("["+method[i].getName().replace("get", "")+"] [varchar](255)");
				}
				
			}
        }
		sql.append(")");
		executeUpdateSQl(sql.toString());
	}
	
	
	public <M> void insertStrPOJO(String tablename,Class<M> mClass,List<Object> list) {
		insertStrPOJO(tablename,mClass,list,200);
	}
	
	//通用, 以後用這個
	public <M> void insertStrPOJO(String tablename,Class<M> mClass,List<Object> list,int valueOfLenLimit) {
		
		//Connect to SQL Server
        Connection connMSSQL;
        int batchSize = 1000;
        int count = 0;
        try {
        	try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
        	
            connMSSQL = DriverManager.getConnection(url, username, password);
            StringBuilder sql = new StringBuilder(); 
            StringBuilder sql_values = new StringBuilder(); 
            sql.append("INSERT INTO [dbo].["+tablename+"](");
            //Method [] method = mClass.getDeclaredMethods() ;
            Method [] method = mClass.getMethods() ; //include all methods extending another
            boolean first = true;
    		for(int i = 0; i < method.length; i++){
    			//if(i>100)break;
    			String methodName = method[i].getName();
    			if(methodName.startsWith("get")){
    	             //fields.put(method[i].getName().replace("get", ""), method[i].getReturnType().getName()); 
    				if(!first){
    					sql.append(",");
    					sql_values.append(",");
    				}else{
    					first = false;
    				}
    				sql.append("["+method[i].getName().replace("get", "")+"]");
    				sql_values.append("?");
    			}
            }
    		sql.append(") VALUES (");
    		sql.append(sql_values.toString()+");");

    		
            
            PreparedStatement ps = connMSSQL.prepareStatement(sql.toString());
    		for(Object obj :list){ 
    			M entity = (M)obj;
    			
    			if(entity!=null){
    				int counter = 1;
    				for(int i = 0; i < method.length; i++){
    	    			String methodName = method[i].getName();
    	    			if(methodName.startsWith("get")){
    	    				Object o = null;
							try {
								o = method[i].invoke(entity);
							} catch (Exception e) {
								e.printStackTrace();
							}
							
							if(method[i].getReturnType().getName().equals("java.util.Date")){
								if(o==null){
									ps.setTimestamp(counter, null);
								}else{
									ps.setTimestamp(counter, new Timestamp(((Date)o).getTime()));
								}
								
							}else{
								/*if(counter==53){
									log.info(counter+"["+methodName+"],"+method[i].getReturnType().getName()+"o:"+o+";"+nullHandle(o));
								}
								log.info(counter+"["+methodName+"],"+method[i].getReturnType().getName()+"o:"+o+";"+nullHandle(o));*/
								try{
									ps.setString(counter, nullHandle(o,valueOfLenLimit));
								}catch(Exception e){
									
								}
								
							}
							
    	    				
    	    				counter++;
    	    			}
    				}
                	ps.addBatch();

                	if(++count % batchSize == 0) {
                		ps.executeBatch();
                		log.info("one batch save OK count:"+count);
                	}
    			}
    			
            }

    		log.info("batch save OK count:"+count);
            ps.executeBatch();
            connMSSQL.close();
        } catch (SQLException e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			log.error("insertStrPOJO error"+sw.toString());
        } finally {
                connMSSQL=null;
        } 
        // end sql
	}
	
	
	
	public String nullHandle(Object o, int lenLimit) {
		String rtn;
		if (o instanceof Integer || o instanceof Double || o instanceof Long) {
			rtn = o == null ? "null" : o.toString();
		} else {
			rtn = o == null ? "null" : o.toString();
		}
		if (lenLimit > 0) {
			if (rtn.length() > lenLimit)
				rtn = rtn.substring(0, lenLimit - 1);
		}
		return rtn;
	}

	public String nullToString(Object o) {
		String rtn;
		if(o instanceof Integer || o instanceof Double){
			rtn = o==null?"0":o.toString();
		}else if(o instanceof Long){
			rtn = o==null?"0":o.toString();
		}else{
			rtn = o==null?"null":o.toString();
		}
		if(rtn.length()>200) rtn = rtn.substring(0, 199);
		return rtn;
	}
	public Integer nullToInt(Object o) {
		if(o instanceof Integer){
			return o==null?0:(Integer)o;
		}else{
			return o==null?0:Integer.parseInt(o.toString());
		}
	}

	public String getServer() {
		return server;
	}


	public void setServer(String server) {
		this.server = server;
	}


	public String getDatabase() {
		return database;
	}


	public void setDatabase(String database) {
		this.database = database;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
}
