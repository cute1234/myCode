package com.newegg.bi.utils.monitor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;



public class IntegrateMonitorEntity{
	private boolean status;
	private String processDateTime;
	//忽略該欄位，讓他不要顯示

	@JsonIgnore
	private String type;
	@JsonIgnore
	private String service;
	@JsonIgnore
	private String jobName;
	private Object response;
	private List<String> reference;
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getProcessDateTime() {
		return processDateTime;
	}
	public void setProcessDateTime(String processDateTime) {
		this.processDateTime = processDateTime;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public Object getResponse() {
		return response;
	}
	public void setResponse(Object response) {
		this.response = response;
	}
	public List<String> getReference() {
		return reference;
	}
	public void setReference(List<String> reference) {
		this.reference = reference;
	}


}
