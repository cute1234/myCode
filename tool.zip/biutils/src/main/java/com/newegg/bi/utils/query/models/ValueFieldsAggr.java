package com.newegg.bi.utils.query.models;

import java.util.List;

public class ValueFieldsAggr {
	public ValueFieldsAggr() {
	}

	public ValueFieldsAggr(String type) {
		this.type = type;
	}

	
	public ValueFieldsAggr(String type, String name) {
		this.type = type;
		this.name = name;
		this.fieldName = name;
	}

	public ValueFieldsAggr(String type, String name, String fieldName) {
		this.type = type;
		this.name = name;
		this.fieldName = fieldName;
	}

	public ValueFieldsAggr(String type, String name, String fn, List<ValueFieldsAggr> fields) {
		this.type = type;
		this.name = name;
		this.fn = fn;
		this.fields = fields;
	}

	private String type;
	private String name;
	private String fieldName;
	private String fn;
	private List<ValueFieldsAggr> fields;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFn() {
		return fn;
	}

	public void setFn(String fn) {
		this.fn = fn;
	}

	public List<ValueFieldsAggr> getFields() {
		return fields;
	}

	public void setFields(List<ValueFieldsAggr> fields) {
		this.fields = fields;
	}

}
