package com.newegg.bi.utils.logx;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LogXRequest<T> {
    @JsonProperty("LogType")
    private Integer logType;

    @JsonProperty("Log")
    private List<T> log;

    public LogXRequest(){
    }

    public Integer getLogType() { return logType;}

    public void setLogType(Integer value) { logType = value;}

    public List<T> getLog() { return log;}

    public void setLog(List<T> value) { log = value;}
}
